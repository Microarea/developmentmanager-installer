param(
    [string]$exe,
    [string]$installationFolder,
    [string]$latestJsonFile
)

try {

    $uninstall = powershell "$exe --uninstall" *> $null;
    Remove-Item -LiteralPath "$installationFolder" -Force -Recurse -ErrorAction SilentlyContinue; 
    Remove-Item -LiteralPath "$latestJsonFile" -Force -ErrorAction SilentlyContinue;
}
catch {
    # Ignora gli errori oppure scrivili in un log
}