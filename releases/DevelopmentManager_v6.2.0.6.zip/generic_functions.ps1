$nodeVersion = "24.15.0"
$netHostBundleId = "Microsoft.DotNet.HostingBundle.10"
$vcRedistId = "Microsoft.VCRedist.2015+.x64"

#-------------------------------------------------------------------------------------------------
function ExistFile([string] $fileFullPath)
{
	If ($fileFullPath -eq '') {	
		write-host non esiste
		return $false;
	}
	
	return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
}

#-------------------------------------------------------------------------------------------------
function ExistFolder([string] $folderFullPath) {
	If ($folderFullPath -eq '') {	
		return $false;
	}

	return  Test-Path $folderFullPath -PathType Container -ErrorAction SilentlyContinue
}

#-------------------------------------------------------------------------------------------------
function ExistBucket([string] $search) {
	$bucketPath = "$env:USERPROFILE\scoop\buckets\$search"
	return ExistFolder $bucketPath
}

#-------------------------------------------------------------------------------------------------
function IsScoopInstalled()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	return ![string]::IsNullOrWhitespace($scoopMainFile)	
}

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"
}

#-------------------------------------------------------------------------------------------------
function CheckNodePrerequisites()
{
	$node = scoop which node
	if ($node)
	{
		write-host "node already installed"
	}
	else
	{
		$installNodeLts = nvm install $nodeVersion
		$useNodeLts = nvm use $nodeVersion
	}
}
#-------------------------------------------------------------------------------------------------
function CheckIfAppExistInScoop([string] $processName)
{
	$processFile = scoop which $processName
	$alreadyExistFile = ExistFile $processFile 
	If ($alreadyExistFile -eq $true) {	
		return $true
	}
	
	return $false
}

#-------------------------------------------------------------------------------------------------
function CheckAndInstallWithScoop([string] $processName)
{
	Write-Host checking $processName installation...
	
	$processFile = scoop which $processName
	$alreadyExistFile = ExistFile $processFile 
	If ($alreadyExistFile -eq $true) {	
		Write-Host $processName already installed -ForegroundColor Green
		return $processFile
	}
	
	Write-Host  $processName not found, installing...
	$installResult = scoop install -g $processName
	$processFile = scoop which $processName
	
	$alreadyExistFile = ExistFile $processFile 
	If ($alreadyExistFile -eq $false) {	
		Write-Host $processName installation failed -ForegroundColor Red
		return $processFile
	}

	return $processFile
}

#-------------------------------------------------------------------------------------------------
function CheckWingetPackageExistance([string] $packageId)
{
	$wingetList = winget list --id $packageId --exact --accept-source-agreements
	if ($wingetList -match [regex]::Escape($packageId))
	{
		return $true
	}
	else
	{
		return $false
	}
}
