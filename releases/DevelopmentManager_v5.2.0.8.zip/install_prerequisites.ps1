$apps = @(
		[pscustomobject]@{AppName='nvm';Version='1.1.11'}
		[pscustomobject]@{AppName='zstd';Version='1.5.5'}
		[pscustomobject]@{AppName='winget';Version='1.8.1911'}
		[pscustomobject]@{AppName='git';Version='2.47.0'}
   )

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"
}

#-------------------------------------------------------------------------------------------------
function ExecuteScoopInstall([string] $package)
{
	$job = Start-Job -ScriptBlock {
		param($processName)
		CheckAndInstallWithScoop -processName $processName
	} -ArgumentList  $package -InitializationScript $scriptBlock
	return $job
}

#-------------------------------------------------------------------------------------------------
function ExecuteNpmInstall([string] $package, [string] $version)
{
	$job = Start-Job -ScriptBlock {
		param($package, $version)
		CheckAndInstallWithNpm -package $package -version $version
	} -ArgumentList $package,  $version  -InitializationScript $scriptBlock
	return $job
}

$scriptBlock = 
{
	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopVersionNumber([string] $scoopAppName)
	{
		ForEach ($app In $apps)
		{
			if ($app.AppName -eq $scoopAppName)
			{
				return $app.Version
			}
		}
	
		return ""
	}

	#-------------------------------------------------------------------------------------------------
	function ExistFile([string] $fileFullPath)
	{
		If ($fileFullPath -eq '') {	
			write-host non esiste
			return $false;
		}
	
		return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
	}


	#-------------------------------------------------------------------------------------------------
	function InstallWithScoop([string] $processName, [string] $version)
	{
		Write-Host installing $processName ...
	
		$proc  = $processName
		If (![string]::IsNullOrWhitespace($version)) {		
		
			$proc += "@" + $version
			write-host $proc
		}
		$processingInstall = scoop install -g $proc	
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithScoop([string] $processName)
	{
		Write-Host checking $processName installation...
	
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
	
		If ($alreadyExistFile -eq $true) 
		{	
			Write-Host $processName already installed -ForegroundColor Green
			return $processFile
		}
	
		Write-Host  $processName not found, installing...
	
		$version = RetrieveScoopVersionNumber $processName
	
		InstallWithScoop $processName $version
	
		$path = RetrieveScoopPath $processName

		return $path 
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithNpm([string] $package, [string] $version)
	{
		$string = npm list --depth 0 --global $package | findstr $package
		if (![string]::IsNullOrEmpty($string)) 
		{
			Write-host "$package found"
			return
		}
	
		$packageWithVersion = $package
		if (![string]::IsNullOrEmpty($version))
		{
			$packageWithVersion = "$packageWithVersion@$version"
		}
		write-host "npm i -g $packageWithVersion"
		$res = npm i -g $packageWithVersion
	}
}

Write-host Checking prerequisites, please wait...

InstallScoopIfNeeded

$jobArray = New-Object -TypeName System.Collections.ArrayList

 [void]$jobArray.Add((ExecuteScoopInstall "git" )) 
 [void]$jobArray.Add((ExecuteScoopInstall "zstd"))
 [void]$jobArray.Add((ExecuteScoopInstall "winget"))
 [void]$jobArray.Add((ExecuteScoopInstall "nvm"))

Receive-Job -Job $jobArray  -Wait 

$nodeVersion="22.11.0" 
nvm install $nodeVersion 
nvm use $nodeVersion 

$jobArray.Clear()

 [void]$jobArray.Add((ExecuteNpmInstall "rimraf" "6.0.1" ))
 [void]$jobArray.Add((ExecuteNpmInstall "@angular/cli" "18.2.5"))

Receive-Job -Job $jobArray  -Wait 

Write-Host prerequisites successfully installed
# SIG # Begin signature block
# MIIpWgYJKoZIhvcNAQcCoIIpSzCCKUcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCLA/Gs7L0bdftJ
# RE8CH12Nh0wHuj183gA8zPwSvZ7ZOaCCDhAwggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggdYMIIFQKADAgECAhALY7FEOp3D0E4VNYGo0wZaMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwMTA3MDAwMDAwWhcNMjgwMTA2
# MjM1OTU5WjBgMQswCQYDVQQGEwJJVDESMBAGA1UECBMJTG9tYmFyZGlhMQ0wCwYD
# VQQHEwRMb2RpMRYwFAYDVQQKEw1adWNjaGV0dGkgU3BBMRYwFAYDVQQDEw1adWNj
# aGV0dGkgU3BBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3TaQlQcB
# gxfabFLVq5czkhW1gTdCfXaoUnx2VRkKnlDbeA/mktrWbKwKBQCGLboy734CoJz/
# 7aQys0sQJ25CLh7Btcu8OKpTgyV1oO4sIg8z2XYOA258LFYW0dlDdkBpU6nOsaSI
# Ubefsa+2WLOA9V1BI7P54GbSVPbcam9AsM4bI6pH+PxxPHIR24LLXOxmLx6UMiP3
# QILtPlasERpDL/l19mnpAr8EaHavGBHLYgZRtqxS5fG6o4fG+Dkd9l2Mxveb3OGX
# LesJquS3h9NRfVwEEImjTUMRcHIJwNxz1hm9d8yxWUc5M2jhiN3FMsvHRgi6/skI
# EAvZuNX6obNG3Sm/PR3+M+KNVEa0BS0zHUGzEjbw6KzS4fKLFWtnkdYwE5g3A0nr
# kX8YURP5YoySbkV07qJ/cu+pgcfmU5oCk8bIUYFK3cVCuRGsqbCj1h8jjriXSXei
# fgx47CvTHA2XozCuYnUeoZQkmc+nhF7LqrbRdRtJVXdQpucb5N/QoDW0z9XmIY33
# fLWnPH86yK9MP3QP95B03VR4vgW0zzHzeYOC8pU/eKLdMjlgE4NXmI7p1a+cwjQX
# A6H9yJ6N0v4g/c1fI1sjHCrihZ7V9+JgojZSbBCST/PsWp+IrZSK5xvNZNfT1NgV
# +u5l3SKaLcxY+lzzypd/3YTHoGdI3I74JakCAwEAAaOCAgMwggH/MB8GA1UdIwQY
# MBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBQEQbu7d7WI8BgYORO6
# AXiqJbpJuTA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0Ex
# LmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0
# MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAP790s7hk
# /lROJkN/2hncbK45xQUhaE7snFu5NPI76RP2moIW7v6xEtc2cTHOAU/Bh5NqWtOW
# v1hKVNX2AbTPiMKq0ghVA3gE8LC6mePQgCDNNWM0VFWlAwFFr+mXXWJeWEQIdKYD
# AHWwR0KyvseKy5FQWQXo46RHClsLhWn3VTkZOkz9ErEj5akP7jLfDBjizVx/6B5/
# Nf8FJZwpy+EsJY4hCgsLtcgWrESKPRZnhccDlmG9IFPm7DUktf7By4U+IZJDQVFh
# rP0AwB7HxiP/JCds1IkFBUA05hC2iD0Ybg11UVSGwI8w+RfRMPCCX6WPUMOiT8Vq
# q4+JGM7grPv9rTxhilH14WxF4UJB4osO1ySVuPl9IXp/QJjbs81TiQKMaxYnCNC2
# wOcqibyzqNUkGWhpX6edZ18fRAXU6AxRu7GAQ4dDYP6sNqa2u606yTFMG8IEg6Fw
# 5X7bot90i/uez57mZfo52VQF1dmojsAgvwuGczgHfiHr5BWTDo+QijfNbE9vEOTC
# YVWTco7R5Hoxkg6O4b8lhs5xMfZA0MRXImHxQ+rwMduiJbBN/abvVxUy0jXhwpk0
# 5OyRm1OwoFnHX4atFv4iJcBm3IhkqFymhS6pJA4gVv6PnhPT0AqcDisGXLnYbvTa
# VWWP9NlY/Mm6qNlFK7vczdsxO3tftKXFfAwxghqgMIIanAIBATB9MGkxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNl
# cnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBD
# QTECEAtjsUQ6ncPQThU1gajTBlowDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3
# AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgISVmDkkkm4BCvAoNe3Lj
# WN+NCYIJYZEs5q4vr0ER7rEwDQYJKoZIhvcNAQEBBQAEggIAyu+ExOJrotNRA1iS
# I2DkvEToqF6Xj0e0XjhWuPtHe4VcrvtMPvlH1IS3WKFHCXlK54D0jvjAxsTDeRD9
# JguVOSoBcrs964G6yFE5iFEJE8HV59H6v0KSJGEHUyxaAkC0Q9V3wkmHpdeIRkVj
# biwwXIaAL38irDYxecqgGJpylp4m+03VGK6UtZfIHRBaR6QoxXx7p6DpUvV+7C8b
# rsJrJ6iZNu9EqaHfe5uuuB6m5AduPfyB9wF1tALcH6UZTlr0c5wabI7Doavoqs+9
# oB2vI2g3zNPpixDzWxGZxCswDy13VIgXD/E8/4dM2/CxgIj09A6XvHySgCga9UUr
# cRPZTD5UwlFjlhtcCWtqsaPwSm0z87am85O2qLGOhaTB2iliNnKb8lwtzRfhZEyB
# OitKURBV4K4OfJwWUNs3pMD2fycS7FuGX+IjnC5ru5BeQJ9fmgYG21sZVbU2vocl
# dPxTq4zm3WF2mXFOU/KFq6G/5+r8AZsv1Y2pnqwSfQyNlx6XXyiy03TzSBVrkwdm
# Sm0JlybeWFagUwScE7zE83j+3kzzqD5aPr0k2g2orYBAtygoxUYI2dmOYaAqo4u2
# 4YpSxjZ1maAidiTVBR305vMbxdaQBOF/+pzHhutZXO9jWgvgfFFSYfzy6qKKiZNs
# iBlMecVLqvuZDDJBzz341Td1rOShghd2MIIXcgYKKwYBBAGCNwMDATGCF2Iwghde
# BgkqhkiG9w0BBwKgghdPMIIXSwIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3
# DQEJEAEEoGgEZjBkAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgGML3
# Sjw09IIZrjm7mB+ILXysa13RPQLoiUIGnTk44ugCEGUyB9x6cjX/q0Un5a+od+8Y
# DzIwMjUwODEyMDczMzQ5WqCCEzowggbtMIIE1aADAgECAhAKgO8YS43xBYLRxHan
# lXRoMA0GCSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdp
# Q2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3Rh
# bXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAwMDAwWhcN
# MzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQs
# IEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRpbWVzdGFt
# cCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEA0EasLRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7C8Dr0cVM
# F3BsfAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281mHrBbZHqR
# K71Em3/hCGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUueHTQKWXym
# OtRwJXcrcTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw44wDcKgH
# +JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBSai25CFyD
# 23DZgPfDrJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvhDU6lvJuk
# x7jphx40DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5J4dVmVzi
# x4A77p3awLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIUbWuhKuAe
# NIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJRE7Ce7vM
# RHoRon4CWIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CIDBbTRofOs
# NyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOCAZUwggGR
# MAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPPYYzoMB8G
# A1UdIwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQEAwIHgDAW
# BgNVHSUBAf8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcwAoZRaHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0
# YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVT
# dGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAXMAgGBmeB
# DAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEcJwS5rmBB
# 7NEIRJ5jQHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz9iZEN/FP
# sLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7YXwBD9R0
# oU62PtgxOao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8lD8QAGB9l
# ctZTTOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42fNBVN4ue
# LaceRf9Cq9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz+BW60OiM
# EgV5GWoBy4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJnzkQTwtS
# SpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7weCC3yXZ
# i/uuhqdwkgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH3EmAp/js
# J3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ueIu9THFVk
# T+um1vshETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6ILs84ZPvm
# povq90K8eWyG2N01c4IhSOxqt81nMIIGtDCCBJygAwIBAgIQDcesVwX/IZkuQEMi
# DDpJhjANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjUwNTA3MDAwMDAwWhcNMzgwMTE0
# MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# QTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQw
# OTYgU0hBMjU2IDIwMjUgQ0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAtHgx0wqYQXK+PEbAHKx126NGaHS0URedTa2NDZS1mZaDLFTtQ2oRjzUXMmxC
# qvkbsDpz4aH+qbxeLho8I6jY3xL1IusLopuW2qftJYJaDNs1+JH7Z+QdSKWM06qc
# hUP+AbdJgMQB3h2DZ0Mal5kYp77jYMVQXSZH++0trj6Ao+xh/AS7sQRuQL37QXbD
# hAktVJMQbzIBHYJBYgzWIjk8eDrYhXDEpKk7RdoX0M980EpLtlrNyHw0Xm+nt5pn
# YJU3Gmq6bNMI1I7Gb5IBZK4ivbVCiZv7PNBYqHEpNVWC2ZQ8BbfnFRQVESYOszFI
# 2Wv82wnJRfN20VRS3hpLgIR4hjzL0hpoYGk81coWJ+KdPvMvaB0WkE/2qHxJ0ucS
# 638ZxqU14lDnki7CcoKCz6eum5A19WZQHkqUJfdkDjHkccpL6uoG8pbF0LJAQQZx
# st7VvwDDjAmSFTUms+wV/FbWBqi7fTJnjq3hj0XbQcd8hjj/q8d6ylgxCZSKi17y
# Vp2NL+cnT6Toy+rN+nM8M7LnLqCrO2JP3oW//1sfuZDKiDEb1AQ8es9Xr/u6bDTn
# YCTKIsDq1BtmXUqEG1NqzJKS4kOmxkYp2WyODi7vQTCBZtVFJfVZ3j7OgWmnhFr4
# yUozZtqgPrHRVHhGNKlYzyjlroPxul+bgIspzOwbtmsgY1MCAwEAAaOCAV0wggFZ
# MBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFO9vU0rp5AZ8esrikFb2L9RJ
# 7MtOMB8GA1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQE
# AwIBhjATBgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5j
# cnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJ
# YIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQAXzvsWgBz+Bz0RdnEwvb4LyLU0
# pn/N0IfFiBowf0/Dm1wGc/Do7oVMY2mhXZXjDNJQa8j00DNqhCT3t+s8G0iP5kvN
# 2n7Jd2E4/iEIUBO41P5F448rSYJ59Ib61eoalhnd6ywFLerycvZTAz40y8S4F3/a
# +Z1jEMK/DMm/axFSgoR8n6c3nuZB9BfBwAQYK9FHaoq2e26MHvVY9gCDA/JYsq7p
# GdogP8HRtrYfctSLANEBfHU16r3J05qX3kId+ZOczgj5kjatVB+NdADVZKON/gnZ
# ruMvNYY2o1f4MXRJDMdTSlOLh0HCn2cQLwQCqjFbqrXuvTPSegOOzr4EWj7PtspI
# HBldNE2K9i697cvaiIo2p61Ed2p8xMJb82Yosn0z4y25xUbI7GIN/TpVfHIqQ6Ku
# /qjTY6hc3hsXMrS+U0yy+GWqAXam4ToWd2UQ1KYT70kZjE4YtL8Pbzg0c1ugMZyZ
# Zd/BdHLiRu7hAWE6bTEm4XYRkA6Tl4KSFLFk43esaUeqGkH/wyW4N7OigizwJWeu
# kcyIPbAvjSabnf7+Pu0VrFgoiovRDiyx3zEdmcif/sYQsfch28bZeUz2rtY/9TCA
# 6TD8dC3JE3rYkrhLULy7Dc90G6e8BlqmyIjlgp2+VqsS9/wQD7yFylIz0scmbKvF
# oW2jNrbM1pD2T7m3XDCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJ
# KoZIhvcNAQEMBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQg
# QXNzdXJlZCBJRCBSb290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1
# OVowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBS
# b290IEc0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+Rd
# SjwwIjBpM+zCpyUuySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20d
# q7J58soR0uRf1gU8Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7f
# gvMHhOZ0O21x4i0MG+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRA
# X7F6Zu53yEioZldXn1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raR
# mECQecN4x7axxLVqGDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzU
# vK4bA3VdeGbZOjFEmjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2
# mHY9WV1CdoeJl2l6SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkr
# fsCUtNJhbesz2cXfSwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaA
# sPvoZKYz0YkH4b235kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxf
# jT/JvNNBERJb5RBQ6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEe
# xcCPorF+CiaZ9eRpL5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQF
# MAMBAf8wHQYDVR0OBBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaA
# FEXroq/0ksuCMS1Ri6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcB
# AQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggr
# BgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNz
# dXJlZElEUm9vdENBLmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQK
# MAgwBgYEVR0gADANBgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3
# v1cHvZqsoYcs7IVeqRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy
# 3iS8UgPITtAq3votVs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cn
# RNTnf+hZqPC/Lwum6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3
# WlxUjG/voVA9/HYJaISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2
# zm8jLfR+cWojayL/ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDGC
# A3wwggN4AgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBS
# U0E0MDk2IFNIQTI1NiAyMDI1IENBMQIQCoDvGEuN8QWC0cR2p5V0aDANBglghkgB
# ZQMEAgEFAKCB0TAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTI1MDgxMjA3MzM0OVowKwYLKoZIhvcNAQkQAgwxHDAaMBgwFgQU3WIw
# rIYKLTBr2jixaHlSMAf7QX4wLwYJKoZIhvcNAQkEMSIEILb6VQe4foygpzJlWOYk
# 49/XRFHq7KmPvy/rz33yAOGpMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIEqgP6Is
# 11yExVyTj4KOZ2ucrsqzP+NtJpqjNPFGEQozMA0GCSqGSIb3DQEBAQUABIICAJEV
# aSWG2N1qgtjlH4SGCiS00NAgGxSzcyXmeZSzpml64LV8M8yX3Yg6VfNXMEwdSR4F
# LKnyHGSBDdfEbzfsc/a2blRrtFWN9vkBK75rdq5zp34BlD7DrU7FA40w44oZMjd5
# GLpxGVtDiBRCEu1kxitlSUvLsBfVZCtWV+CoOSgYB2Z6wbkAGM9J/Gk/ugU9z+C7
# kwaH9DW7IzHnKK041rZafc/dRA1uAQM1XAmtHaX5WlHt6VYuzQAFGrGPOXVrGNoh
# yUkuBh0RnXPm8KJwcyINO+XRteJLKBQCTMfLbLVCvRfzJLw5sp9/qHKQ9sSgx5JT
# YCee0XE1masUNCrQaGVWd4KAkmraMC5LLZxNCWyGTnDy+AyWi4ncK+5rVW9YW1fw
# mXbmWqOjfpGcw4yYh++t9PTCWi5Bq/MXU11E7/DpHCh5vCzO1ARg16Yn7KFIwQHG
# 9B6l1zrnSZ+B/CBKT9qGjNu/UlwzDenP6PYgdpzCV/yM0HZTN3Q7ubHnPI5f4z9D
# 071AcpFRvsdAaxNzn3qkLPgLcaZZtmSh46OtQmdophrXbS6dyODfTxAzKnjU2aek
# uFN2jMA6g8+LLsBhXDIwQpvX1sxgYdcbNzfuL4sDiCB62l1jl36doa0VDlRU7dFv
# nIXaQiXpExpsA/a8nJrH4cJtg90jX2E7MeYZObxo
# SIG # End signature block
