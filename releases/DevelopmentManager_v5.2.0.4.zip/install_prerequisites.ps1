$apps = @(
		[pscustomobject]@{AppName='nvm';Version='1.1.11'}
		[pscustomobject]@{AppName='zstd';Version='1.5.5'}
		[pscustomobject]@{AppName='winget';Version='1.8.1911'}
		[pscustomobject]@{AppName='git';Version='2.47.0'}
   )

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"
}

#-------------------------------------------------------------------------------------------------
function ExecuteScoopInstall([string] $package)
{
	$job = Start-Job -ScriptBlock {
		param($processName)
		CheckAndInstallWithScoop -processName $processName
	} -ArgumentList  $package -InitializationScript $scriptBlock
	return $job
}

#-------------------------------------------------------------------------------------------------
function ExecuteNpmInstall([string] $package, [string] $version)
{
	$job = Start-Job -ScriptBlock {
		param($package, $version)
		CheckAndInstallWithNpm -package $package -version $version
	} -ArgumentList $package,  $version  -InitializationScript $scriptBlock
	return $job
}

$scriptBlock = 
{
	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopVersionNumber([string] $scoopAppName)
	{
		ForEach ($app In $apps)
		{
			if ($app.AppName -eq $scoopAppName)
			{
				return $app.Version
			}
		}
	
		return ""
	}

	#-------------------------------------------------------------------------------------------------
	function ExistFile([string] $fileFullPath)
	{
		If ($fileFullPath -eq '') {	
			write-host non esiste
			return $false;
		}
	
		return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
	}


	#-------------------------------------------------------------------------------------------------
	function InstallWithScoop([string] $processName, [string] $version)
	{
		Write-Host installing $processName ...
	
		$proc  = $processName
		If (![string]::IsNullOrWhitespace($version)) {		
		
			$proc += "@" + $version
			write-host $proc
		}
		$processingInstall = scoop install -g $proc	
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithScoop([string] $processName)
	{
		Write-Host checking $processName installation...
	
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
	
		If ($alreadyExistFile -eq $true) 
		{	
			Write-Host $processName already installed -ForegroundColor Green
			return $processFile
		}
	
		Write-Host  $processName not found, installing...
	
		$version = RetrieveScoopVersionNumber $processName
	
		InstallWithScoop $processName $version
	
		$path = RetrieveScoopPath $processName

		return $path 
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithNpm([string] $package, [string] $version)
	{
		$string = npm list --depth 0 --global $package | findstr $package
		if (![string]::IsNullOrEmpty($string)) 
		{
			Write-host "$package found"
			return
		}
	
		$packageWithVersion = $package
		if (![string]::IsNullOrEmpty($version))
		{
			$packageWithVersion = "$packageWithVersion@$version"
		}
		write-host "npm i -g $packageWithVersion"
		$res = npm i -g $packageWithVersion
	}
}

Write-host Checking prerequisites, please wait...

InstallScoopIfNeeded

$jobArray = New-Object -TypeName System.Collections.ArrayList

 [void]$jobArray.Add((ExecuteScoopInstall "git" )) 
 [void]$jobArray.Add((ExecuteScoopInstall "zstd"))
 [void]$jobArray.Add((ExecuteScoopInstall "winget"))
 [void]$jobArray.Add((ExecuteScoopInstall "nvm"))

Receive-Job -Job $jobArray  -Wait 

$nodeVersion="22.11.0" 
nvm install $nodeVersion 
nvm use $nodeVersion 

$jobArray.Clear()

 [void]$jobArray.Add((ExecuteNpmInstall "rimraf" "6.0.1" ))
 [void]$jobArray.Add((ExecuteNpmInstall "@angular/cli" "18.2.5"))

Receive-Job -Job $jobArray  -Wait 

Write-Host prerequisites successfully installed
# SIG # Begin signature block
# MIIpWwYJKoZIhvcNAQcCoIIpTDCCKUgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCLA/Gs7L0bdftJ
# RE8CH12Nh0wHuj183gA8zPwSvZ7ZOaCCDhAwggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggdYMIIFQKADAgECAhALY7FEOp3D0E4VNYGo0wZaMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjUwMTA3MDAwMDAwWhcNMjgwMTA2
# MjM1OTU5WjBgMQswCQYDVQQGEwJJVDESMBAGA1UECBMJTG9tYmFyZGlhMQ0wCwYD
# VQQHEwRMb2RpMRYwFAYDVQQKEw1adWNjaGV0dGkgU3BBMRYwFAYDVQQDEw1adWNj
# aGV0dGkgU3BBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3TaQlQcB
# gxfabFLVq5czkhW1gTdCfXaoUnx2VRkKnlDbeA/mktrWbKwKBQCGLboy734CoJz/
# 7aQys0sQJ25CLh7Btcu8OKpTgyV1oO4sIg8z2XYOA258LFYW0dlDdkBpU6nOsaSI
# Ubefsa+2WLOA9V1BI7P54GbSVPbcam9AsM4bI6pH+PxxPHIR24LLXOxmLx6UMiP3
# QILtPlasERpDL/l19mnpAr8EaHavGBHLYgZRtqxS5fG6o4fG+Dkd9l2Mxveb3OGX
# LesJquS3h9NRfVwEEImjTUMRcHIJwNxz1hm9d8yxWUc5M2jhiN3FMsvHRgi6/skI
# EAvZuNX6obNG3Sm/PR3+M+KNVEa0BS0zHUGzEjbw6KzS4fKLFWtnkdYwE5g3A0nr
# kX8YURP5YoySbkV07qJ/cu+pgcfmU5oCk8bIUYFK3cVCuRGsqbCj1h8jjriXSXei
# fgx47CvTHA2XozCuYnUeoZQkmc+nhF7LqrbRdRtJVXdQpucb5N/QoDW0z9XmIY33
# fLWnPH86yK9MP3QP95B03VR4vgW0zzHzeYOC8pU/eKLdMjlgE4NXmI7p1a+cwjQX
# A6H9yJ6N0v4g/c1fI1sjHCrihZ7V9+JgojZSbBCST/PsWp+IrZSK5xvNZNfT1NgV
# +u5l3SKaLcxY+lzzypd/3YTHoGdI3I74JakCAwEAAaOCAgMwggH/MB8GA1UdIwQY
# MBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBQEQbu7d7WI8BgYORO6
# AXiqJbpJuTA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNI
# QTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0Ex
# LmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0
# MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAP790s7hk
# /lROJkN/2hncbK45xQUhaE7snFu5NPI76RP2moIW7v6xEtc2cTHOAU/Bh5NqWtOW
# v1hKVNX2AbTPiMKq0ghVA3gE8LC6mePQgCDNNWM0VFWlAwFFr+mXXWJeWEQIdKYD
# AHWwR0KyvseKy5FQWQXo46RHClsLhWn3VTkZOkz9ErEj5akP7jLfDBjizVx/6B5/
# Nf8FJZwpy+EsJY4hCgsLtcgWrESKPRZnhccDlmG9IFPm7DUktf7By4U+IZJDQVFh
# rP0AwB7HxiP/JCds1IkFBUA05hC2iD0Ybg11UVSGwI8w+RfRMPCCX6WPUMOiT8Vq
# q4+JGM7grPv9rTxhilH14WxF4UJB4osO1ySVuPl9IXp/QJjbs81TiQKMaxYnCNC2
# wOcqibyzqNUkGWhpX6edZ18fRAXU6AxRu7GAQ4dDYP6sNqa2u606yTFMG8IEg6Fw
# 5X7bot90i/uez57mZfo52VQF1dmojsAgvwuGczgHfiHr5BWTDo+QijfNbE9vEOTC
# YVWTco7R5Hoxkg6O4b8lhs5xMfZA0MRXImHxQ+rwMduiJbBN/abvVxUy0jXhwpk0
# 5OyRm1OwoFnHX4atFv4iJcBm3IhkqFymhS6pJA4gVv6PnhPT0AqcDisGXLnYbvTa
# VWWP9NlY/Mm6qNlFK7vczdsxO3tftKXFfAwxghqhMIIanQIBATB9MGkxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNl
# cnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBD
# QTECEAtjsUQ6ncPQThU1gajTBlowDQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3
# AgEMMQIwADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgISVmDkkkm4BCvAoNe3Lj
# WN+NCYIJYZEs5q4vr0ER7rEwDQYJKoZIhvcNAQEBBQAEggIAyu+ExOJrotNRA1iS
# I2DkvEToqF6Xj0e0XjhWuPtHe4VcrvtMPvlH1IS3WKFHCXlK54D0jvjAxsTDeRD9
# JguVOSoBcrs964G6yFE5iFEJE8HV59H6v0KSJGEHUyxaAkC0Q9V3wkmHpdeIRkVj
# biwwXIaAL38irDYxecqgGJpylp4m+03VGK6UtZfIHRBaR6QoxXx7p6DpUvV+7C8b
# rsJrJ6iZNu9EqaHfe5uuuB6m5AduPfyB9wF1tALcH6UZTlr0c5wabI7Doavoqs+9
# oB2vI2g3zNPpixDzWxGZxCswDy13VIgXD/E8/4dM2/CxgIj09A6XvHySgCga9UUr
# cRPZTD5UwlFjlhtcCWtqsaPwSm0z87am85O2qLGOhaTB2iliNnKb8lwtzRfhZEyB
# OitKURBV4K4OfJwWUNs3pMD2fycS7FuGX+IjnC5ru5BeQJ9fmgYG21sZVbU2vocl
# dPxTq4zm3WF2mXFOU/KFq6G/5+r8AZsv1Y2pnqwSfQyNlx6XXyiy03TzSBVrkwdm
# Sm0JlybeWFagUwScE7zE83j+3kzzqD5aPr0k2g2orYBAtygoxUYI2dmOYaAqo4u2
# 4YpSxjZ1maAidiTVBR305vMbxdaQBOF/+pzHhutZXO9jWgvgfFFSYfzy6qKKiZNs
# iBlMecVLqvuZDDJBzz341Td1rOShghd3MIIXcwYKKwYBBAGCNwMDATGCF2Mwghdf
# BgkqhkiG9w0BBwKgghdQMIIXTAIBAzEPMA0GCWCGSAFlAwQCAQUAMHgGCyqGSIb3
# DQEJEAEEoGkEZzBlAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgGML3
# Sjw09IIZrjm7mB+ILXysa13RPQLoiUIGnTk44ugCEQDQoZmUvybOae+lEaUzzsGB
# GA8yMDI1MDgxMjA3MTcwM1qgghM6MIIG7TCCBNWgAwIBAgIQCoDvGEuN8QWC0cR2
# p5V0aDANBgkqhkiG9w0BAQsFADBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGln
# aUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0
# YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExMB4XDTI1MDYwNDAwMDAwMFoX
# DTM2MDkwMzIzNTk1OVowYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0
# LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2VydCBTSEEyNTYgUlNBNDA5NiBUaW1lc3Rh
# bXAgUmVzcG9uZGVyIDIwMjUgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBANBGrC0Sxp7Q6q5gVrMrV7pvUf+GcAoB38o3zBlCMGMyqJnfFNZx+wvA69HF
# TBdwbHwBSOeLpvPnZ8ZN+vo8dE2/pPvOx/Vj8TchTySA2R4QKpVD7dvNZh6wW2R6
# kSu9RJt/4QhguSssp3qome7MrxVyfQO9sMx6ZAWjFDYOzDi8SOhPUWlLnh00Cll8
# pjrUcCV3K3E0zz09ldQ//nBZZREr4h/GI6Dxb2UoyrN0ijtUDVHRXdmncOOMA3Co
# B/iUSROUINDT98oksouTMYFOnHoRh6+86Ltc5zjPKHW5KqCvpSduSwhwUmotuQhc
# g9tw2YD3w6ySSSu+3qU8DD+nigNJFmt6LAHvH3KSuNLoZLc1Hf2JNMVL4Q1Opbyb
# pMe46YceNA0LfNsnqcnpJeItK/DhKbPxTTuGoX7wJNdoRORVbPR1VVnDuSeHVZlc
# 4seAO+6d2sC26/PQPdP51ho1zBp+xUIZkpSFA8vWdoUoHLWnqWU3dCCyFG1roSrg
# HjSHlq8xymLnjCbSLZ49kPmk8iyyizNDIXj//cOgrY7rlRyTlaCCfw7aSUROwnu7
# zER6EaJ+AliL7ojTdS5PWPsWeupWs7NpChUk555K096V1hE0yZIXe+giAwW00aHz
# rDchIc2bQhpp0IoKRR7YufAkprxMiXAJQ1XCmnCfgPf8+3mnAgMBAAGjggGVMIIB
# kTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTkO/zyMe39/dfzkXFjGVBDz2GM6DAf
# BgNVHSMEGDAWgBTvb1NK6eQGfHrK4pBW9i/USezLTjAOBgNVHQ8BAf8EBAMCB4Aw
# FgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwgZUGCCsGAQUFBwEBBIGIMIGFMCQGCCsG
# AQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXQYIKwYBBQUHMAKGUWh0
# dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVT
# dGFtcGluZ1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNydDBfBgNVHR8EWDBWMFSgUqBQ
# hk5odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1l
# U3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcmwwIAYDVR0gBBkwFzAIBgZn
# gQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQBlKq3xHCcEua5g
# QezRCESeY0ByIfjk9iJP2zWLpQq1b4URGnwWBdEZD9gBq9fNaNmFj6Eh8/YmRDfx
# T7C0k8FUFqNh+tshgb4O6Lgjg8K8elC4+oWCqnU/ML9lFfim8/9yJmZSe2F8AQ/U
# dKFOtj7YMTmqPO9mzskgiC3QYIUP2S3HQvHG1FDu+WUqW4daIqToXFE/JQ/EABgf
# ZXLWU0ziTN6R3ygQBHMUBaB5bdrPbF6MRYs03h4obEMnxYOX8VBRKe1uNnzQVTeL
# ni2nHkX/QqvXnNb+YkDFkxUGtMTaiLR9wjxUxu2hECZpqyU1d0IbX6Wq8/gVutDo
# jBIFeRlqAcuEVT0cKsb+zJNEsuEB7O7/cuvTQasnM9AWcIQfVjnzrvwiCZ85EE8L
# UkqRhoS3Y50OHgaY7T/lwd6UArb+BOVAkg2oOvol/DJgddJ35XTxfUlQ+8Hggt8l
# 2Yv7roancJIFcbojBcxlRcGG0LIhp6GvReQGgMgYxQbV1S3CrWqZzBt1R9xJgKf4
# 7CdxVRd/ndUlQ05oxYy2zRWVFjF7mcr4C34Mj3ocCVccAvlKV9jEnstrniLvUxxV
# ZE/rptb7IRE2lskKPIJgbaP5t2nGj/ULLi49xTcBZU8atufk+EMF/cWuiC7POGT7
# 5qaL6vdCvHlshtjdNXOCIUjsarfNZzCCBrQwggScoAMCAQICEA3HrFcF/yGZLkBD
# Igw6SYYwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMY
# RGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0MB4XDTI1MDUwNzAwMDAwMFoXDTM4MDEx
# NDIzNTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMu
# MUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0
# MDk2IFNIQTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBALR4MdMKmEFyvjxGwBysddujRmh0tFEXnU2tjQ2UtZmWgyxU7UNqEY81FzJs
# Qqr5G7A6c+Gh/qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzbNfiR+2fkHUiljNOq
# nIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0mR/vtLa4+gKPsYfwEu7EEbkC9+0F2
# w4QJLVSTEG8yAR2CQWIM1iI5PHg62IVwxKSpO0XaF9DPfNBKS7Zazch8NF5vp7ea
# Z2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhxKTVVgtmUPAW35xUUFREmDrMx
# SNlr/NsJyUXzdtFUUt4aS4CEeIY8y9IaaGBpPNXKFifinT7zL2gdFpBP9qh8SdLn
# Eut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x5HHKS+rqBvKWxdCyQEEG
# cbLe1b8Aw4wJkhU1JrPsFfxW1gaou30yZ46t4Y9F20HHfIY4/6vHespYMQmUiote
# 8ladjS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogxG9QEPHrPV6/7umw0
# 52AkyiLA6tQbZl1KhBtTasySkuJDpsZGKdlsjg4u70EwgWbVRSX1Wd4+zoFpp4Ra
# +MlKM2baoD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNTAgMBAAGjggFdMIIB
# WTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTvb1NK6eQGfHrK4pBW9i/U
# SezLTjAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8E
# BAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYIKwYBBQUHAQEEazBpMCQGCCsG
# AQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKGNWh0
# dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQu
# Y3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsG
# CWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAF877FoAc/gc9EXZxML2+C8i1
# NKZ/zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAzaoQk97frPBtIj+ZL
# zdp+yXdhOP4hCFATuNT+ReOPK0mCefSG+tXqGpYZ3essBS3q8nL2UwM+NMvEuBd/
# 2vmdYxDCvwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntujB71WPYAgwPyWLKu
# 6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOal95CHfmTnM4I+ZI2rVQfjXQA1WSjjf4J
# 2a7jLzWGNqNX+DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z0noDjs6+BFo+z7bK
# SBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/NmKLJ9M+MtucVGyOxiDf06VXxyKkOi
# rv6o02OoXN4bFzK0vlNMsvhlqgF2puE6FndlENSmE+9JGYxOGLS/D284NHNboDGc
# mWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3rGlHqhpB/8MluDezooIs8CVn
# rpHMiD2wL40mm53+/j7tFaxYKIqL0Q4ssd8xHZnIn/7GELH3IdvG2XlM9q7WP/Uw
# gOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlarEvf8EA+8hcpSM9LHJmyr
# xaFtoza2zNaQ9k+5t1wwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0G
# CSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0
# IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5
# NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQg
# Um9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvk
# XUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdt
# HauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu
# 34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0
# QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2
# kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM
# 1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmI
# dph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZ
# K37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72
# gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqs
# X40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyh
# HsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAW
# gBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUH
# AQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYI
# KwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAE
# CjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX
# 979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offy
# ct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3
# J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0
# d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6ts
# ds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQx
# ggN8MIIDeAIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZI
# AWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3
# DQEJBTEPFw0yNTA4MTIwNzE3MDNaMCsGCyqGSIb3DQEJEAIMMRwwGjAYMBYEFN1i
# MKyGCi0wa9o4sWh5UjAH+0F+MC8GCSqGSIb3DQEJBDEiBCCWfS2HY1WXQwmR56ep
# PwKrp5BYqh+bg0erNDLgIBdiVTA3BgsqhkiG9w0BCRACLzEoMCYwJDAiBCBKoD+i
# LNdchMVck4+CjmdrnK7Ksz/jbSaaozTxRhEKMzANBgkqhkiG9w0BAQEFAASCAgAv
# 7sRnMhzvSRVUm6BBNrFrzlaVrzMTgRTwYlanxTjTGv4+WBAShQeXDNe9fj2JUrbu
# R2hTP/pfpxUVm07hu+YPKNjbOnE3MEvttMJziRwBrsp6BxittmH+5nE5heT5AZu7
# yuLeulDW06OpLaypQPCkCq6qT19XVqyoTE0Swn8dajmRAHLeFxmsZpnUJt+LmNxt
# aDP8qkqQm/KqC+5J4sdf74Htne7dp8OtO5Ai+pJ6bS/TLUueqOXvtOGn2eJoAEng
# Stca7/u6hnWUMmDVZoQaF+o9fW3fPBJJID0L+0hOFuPLGOtQfGkEy44N5cqnVSn9
# TjlnxUA8MxIMA1InvNMrbePabH0SIUi/+uSKOT7zvIpTTEILHip0uyUWEADkkXXC
# L3I11JqYa124tNeqNOvPv+QZvxmCl7xqVykBqs72MSRbCKxzZDTw60zhiyRWcvT0
# p93YbrfXCKsu8Z/r0Awn+5h8hfZyjBqtYmt1MQi5UXnWAOd4lCikeawI5ZHtGxrr
# Ylb7shoDNEi7aWcAjBvXNw2GYgTjplDHNreVtYQCNO32dr56a9iDmutlPLhiueoW
# Fzs2WNuQXmZY2E4TSwnFnyYvTuPQTjfWuKqSU7nz804AHD2HMh0Y56uep7aOPpoH
# oDNaddsYw1n6vGcOibwWEqCbhU6ssmwmVeXgugIr1A==
# SIG # End signature block
