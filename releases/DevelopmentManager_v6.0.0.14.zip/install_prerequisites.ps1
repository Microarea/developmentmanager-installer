$apps = @(
		[pscustomobject]@{AppName='nvm';Version='1.1.11'}
		[pscustomobject]@{AppName='zstd';Version='1.5.5'}
		[pscustomobject]@{AppName='winget';Version='1.8.1911'}
		[pscustomobject]@{AppName='git';Version='2.51.0'}
   )

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		scoop update
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"
}

#-------------------------------------------------------------------------------------------------
function ExecuteScoopInstall([string] $package)
{
	$job = Start-Job -ScriptBlock {
		param($processName)
		CheckAndInstallWithScoop -processName $processName
	} -ArgumentList  $package -InitializationScript $scriptBlock
	return $job
}

#-------------------------------------------------------------------------------------------------
function ExecuteNpmInstall([string] $package, [string] $version)
{
	$job = Start-Job -ScriptBlock {
		param($package, $version)
		CheckAndInstallWithNpm -package $package -version $version
	} -ArgumentList $package,  $version  -InitializationScript $scriptBlock
	return $job
}

$scriptBlock = 
{
	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopVersionNumber([string] $scoopAppName)
	{
		ForEach ($app In $apps)
		{
			if ($app.AppName -eq $scoopAppName)
			{
				return $app.Version
			}
		}
	
		return ""
	}

	#-------------------------------------------------------------------------------------------------
	function ExistFile([string] $fileFullPath)
	{
		If ($fileFullPath -eq '') {	
			write-host non esiste
			return $false;
		}
	
		return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
	}


	#-------------------------------------------------------------------------------------------------
	function InstallWithScoop([string] $processName, [string] $version)
	{
		Write-Host installing $processName ...
	
		$proc  = $processName
		If (![string]::IsNullOrWhitespace($version)) {		
		
			$proc += "@" + $version
			write-host $proc
		}
		$processingInstall = scoop install -g $proc	
	}

	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopPath([string] $processName) 
	{
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
		If ($alreadyExistFile -eq $true) {	
			return $processFile
		}
		return $null
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithScoop([string] $processName)
	{
		Write-Host checking $processName installation...
	
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
	
		If ($alreadyExistFile -eq $true) 
		{	
			Write-Host $processName already installed -ForegroundColor Green
			return $processFile
		}
	
		Write-Host  $processName not found, installing...
	
		$version = RetrieveScoopVersionNumber $processName
	
		InstallWithScoop $processName $version
	
		$path = RetrieveScoopPath $processName

		return $path 
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithNpm([string] $package, [string] $version)
	{
		$string = npm list --depth 0 --global $package | findstr $package
		if (![string]::IsNullOrEmpty($string)) 
		{
			Write-host "$package found"
			return
		}
	
		$packageWithVersion = $package
		if (![string]::IsNullOrEmpty($version))
		{
			$packageWithVersion = "$packageWithVersion@$version"
		}
		write-host "npm i -g $packageWithVersion"
		$res = npm i -g $packageWithVersion
	}
}

Write-host Checking prerequisites, please wait...

InstallScoopIfNeeded

$jobArray = New-Object -TypeName System.Collections.ArrayList

 [void]$jobArray.Add((ExecuteScoopInstall "git" )) 
 [void]$jobArray.Add((ExecuteScoopInstall "zstd"))
 [void]$jobArray.Add((ExecuteScoopInstall "winget"))
 [void]$jobArray.Add((ExecuteScoopInstall "nvm"))

Receive-Job -Job $jobArray  -Wait 

$nodeVersion="22.11.0" 
nvm install $nodeVersion 
nvm use $nodeVersion 

$jobArray.Clear()

 [void]$jobArray.Add((ExecuteNpmInstall "rimraf" "6.0.1" ))
 [void]$jobArray.Add((ExecuteNpmInstall "@angular/cli" "18.2.5"))

Receive-Job -Job $jobArray  -Wait 

Write-Host prerequisites successfully installed
# SIG # Begin signature block
# MIIuOAYJKoZIhvcNAQcCoIIuKTCCLiUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBgro70f4K9B1yv
# Swn2R36Nyr5j8eDczl45O19taHTPgaCCE6QwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdYMIIFQKADAgECAhALY7FEOp3D0E4VNYGo0wZaMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjUwMTA3MDAwMDAwWhcNMjgwMTA2MjM1OTU5WjBgMQsw
# CQYDVQQGEwJJVDESMBAGA1UECBMJTG9tYmFyZGlhMQ0wCwYDVQQHEwRMb2RpMRYw
# FAYDVQQKEw1adWNjaGV0dGkgU3BBMRYwFAYDVQQDEw1adWNjaGV0dGkgU3BBMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3TaQlQcBgxfabFLVq5czkhW1
# gTdCfXaoUnx2VRkKnlDbeA/mktrWbKwKBQCGLboy734CoJz/7aQys0sQJ25CLh7B
# tcu8OKpTgyV1oO4sIg8z2XYOA258LFYW0dlDdkBpU6nOsaSIUbefsa+2WLOA9V1B
# I7P54GbSVPbcam9AsM4bI6pH+PxxPHIR24LLXOxmLx6UMiP3QILtPlasERpDL/l1
# 9mnpAr8EaHavGBHLYgZRtqxS5fG6o4fG+Dkd9l2Mxveb3OGXLesJquS3h9NRfVwE
# EImjTUMRcHIJwNxz1hm9d8yxWUc5M2jhiN3FMsvHRgi6/skIEAvZuNX6obNG3Sm/
# PR3+M+KNVEa0BS0zHUGzEjbw6KzS4fKLFWtnkdYwE5g3A0nrkX8YURP5YoySbkV0
# 7qJ/cu+pgcfmU5oCk8bIUYFK3cVCuRGsqbCj1h8jjriXSXeifgx47CvTHA2XozCu
# YnUeoZQkmc+nhF7LqrbRdRtJVXdQpucb5N/QoDW0z9XmIY33fLWnPH86yK9MP3QP
# 95B03VR4vgW0zzHzeYOC8pU/eKLdMjlgE4NXmI7p1a+cwjQXA6H9yJ6N0v4g/c1f
# I1sjHCrihZ7V9+JgojZSbBCST/PsWp+IrZSK5xvNZNfT1NgV+u5l3SKaLcxY+lzz
# ypd/3YTHoGdI3I74JakCAwEAAaOCAgMwggH/MB8GA1UdIwQYMBaAFGg34Ou2O/hf
# EYb7/mF7CIhl9E5CMB0GA1UdDgQWBBQEQbu7d7WI8BgYORO6AXiqJbpJuTA+BgNV
# HSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRwOi8vd3d3LmRpZ2lj
# ZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMD
# MIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEu
# Y3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDCBlAYIKwYB
# BQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQw
# CQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAP790s7hk/lROJkN/2hncbK45
# xQUhaE7snFu5NPI76RP2moIW7v6xEtc2cTHOAU/Bh5NqWtOWv1hKVNX2AbTPiMKq
# 0ghVA3gE8LC6mePQgCDNNWM0VFWlAwFFr+mXXWJeWEQIdKYDAHWwR0KyvseKy5FQ
# WQXo46RHClsLhWn3VTkZOkz9ErEj5akP7jLfDBjizVx/6B5/Nf8FJZwpy+EsJY4h
# CgsLtcgWrESKPRZnhccDlmG9IFPm7DUktf7By4U+IZJDQVFhrP0AwB7HxiP/JCds
# 1IkFBUA05hC2iD0Ybg11UVSGwI8w+RfRMPCCX6WPUMOiT8Vqq4+JGM7grPv9rTxh
# ilH14WxF4UJB4osO1ySVuPl9IXp/QJjbs81TiQKMaxYnCNC2wOcqibyzqNUkGWhp
# X6edZ18fRAXU6AxRu7GAQ4dDYP6sNqa2u606yTFMG8IEg6Fw5X7bot90i/uez57m
# Zfo52VQF1dmojsAgvwuGczgHfiHr5BWTDo+QijfNbE9vEOTCYVWTco7R5Hoxkg6O
# 4b8lhs5xMfZA0MRXImHxQ+rwMduiJbBN/abvVxUy0jXhwpk05OyRm1OwoFnHX4at
# Fv4iJcBm3IhkqFymhS6pJA4gVv6PnhPT0AqcDisGXLnYbvTaVWWP9NlY/Mm6qNlF
# K7vczdsxO3tftKXFfAwxghnqMIIZ5gIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYD
# VQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBH
# NCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTECEAtjsUQ6ncPQ
# ThU1gajTBlowDQYJYIZIAWUDBAIBBQCggYQwGAYKKwYBBAGCNwIBDDEKMAigAoAA
# oQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4w
# DAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgvkCxS2j5MGoGWiC+SCjOrTpc
# JA9cCjEZ1iam/HYtlucwDQYJKoZIhvcNAQEBBQAEggIAapFdCP4vu6CxiUWznZbs
# BsrEeCDMB5p7jyuAdKzwY6ndgh6H2v+ocXiUY8gKuDQrghRXhXPMj6V50iBpXhFS
# wTrVQjnwRQR/uizlp49/jWAm+aLB/K5ZzLez0wV8v5LtJXNYWVy39fIXpAx7CP31
# 6GNUDh6vaPKnpSFZsPmx4/rR4UadNgWMMaQRgAUI+ueXXRgF1IJc1lhj30z2SHxw
# vO6J3/A/ghCpC2y0g6Um9BDI+vmH2piRLfMdAGGBw5EK1425Ye85115K85cohAxN
# C+T/iLOcakFrFqlb1Hj+sS6UghFWG+0/MlPvTJo7+yWT517s9n63c3YbJDpq6xD9
# DB4Rx1asn0IByXckOLkuGn82WY/L7H7aWDqDW3dbIShx/YN8zqdYMYgYD+TdKEtT
# 9m1JOXoJxYL8gWzi0kLoJ0x8A3ahkYByE24ObUzzbSyQZahGnxSRu5/Dsw1MTy60
# XOtaq/q1Rdb2LSQ62fopcrCJGQAf35CDHywTjAk/Q8/AjIU0HDlRnRly1VqPOjdX
# RXqCbcQZc+v8mUJpMSHXKNtcg8YkpINfEhRxaAQfibXNiTUeL9RFs9IUXXIvu0oY
# Nlb7ncQFf/NPYAaTJlZ6jV26D0Ni+Kk2vtJ6PiOHhIXeQXlAGsJMdEGtBciLetV4
# RqcfW3AFnWo0kn96Vfo8ROihgha3MIIWswYKKwYBBAGCNwMDATGCFqMwghafBgkq
# hkiG9w0BBwKgghaQMIIWjAIBAzENMAsGCWCGSAFlAwQCATCB3AYLKoZIhvcNAQkQ
# AQSggcwEgckwgcYCAQEGCSsGAQQBoDICAzAxMA0GCWCGSAFlAwQCAQUABCDRDbuU
# kMjhfAqkyfh6aj8wyEPM9h7s2a0LKb+UcXm9JAIUEkvfDGc6KCqlM33BPyDKcwFg
# b2oYDzIwMjYwMjI2MTAyOTM4WjADAgEBoFekVTBTMQswCQYDVQQGEwJCRTEZMBcG
# A1UECgwQR2xvYmFsU2lnbiBudi1zYTEpMCcGA1UEAwwgR2xvYmFsc2lnbiBUU0Eg
# Zm9yIEFkdmFuY2VkIC0gRzSgghJKMIIGYjCCBEqgAwIBAgIQAQMy4WW/m3hD4Jl1
# lGN3CzANBgkqhkiG9w0BAQwFADBbMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xv
# YmFsU2lnbiBudi1zYTExMC8GA1UEAxMoR2xvYmFsU2lnbiBUaW1lc3RhbXBpbmcg
# Q0EgLSBTSEEzODQgLSBHNDAeFw0yNTA0MTExNDQ3MDFaFw0zNDEyMTAwMDAwMDBa
# MFMxCzAJBgNVBAYTAkJFMRkwFwYDVQQKDBBHbG9iYWxTaWduIG52LXNhMSkwJwYD
# VQQDDCBHbG9iYWxzaWduIFRTQSBmb3IgQWR2YW5jZWQgLSBHNDCCAaIwDQYJKoZI
# hvcNAQEBBQADggGPADCCAYoCggGBAL4lejlDGK511tWzocib1iaenoAWN1mu9Ocn
# g7gqw8zEOq8sty7ryNq/wwWveWzXNhLatjNeMQ0n8+E9A4EbszvuRGgmnjPkyPUm
# JS/gkNkDR/QmZV1BxLysCQEhPewZIEYvQB9sZb3VM2W94iCkRMVacCMtRKq2RsqA
# eeo8vjtsyGm4MgpXSOIJBHM6r4FzKBZy+RsTtzj0Rjg36eklI/nsMLaCIKD+E7dg
# Cl77Yvhvhbx8Gzevdk/vY1H8EQCXBZa6JNtfR6DaLDwsh8gxTczI5sRdI3ymYpNo
# v8ymVwBzun3KW4Msk0BMIn25fcxvb501hIIfKpnXAZEKzaPQGDDxlkx7PNdUzXw+
# eF6eVzJYeToLRXOamOHYrSX++ML0COvPq2sg/GeXlHL1eMb/UhjKKU0rxtig1sjD
# MHswGoQYSfS2zNzW1NoeHRFCgS/OsJ6VgWLclzFIFpGTzArZiKlu8Zabb+XIO8lA
# Px9dQU/6AC0MTpVxG9VJrDCQy0oYTwIDAQABo4IBqDCCAaQwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMB0GA1UdDgQWBBTZN7YzRW6PNQfO
# 96mzCv2gqcj5gjBWBgNVHSAETzBNMAgGBmeBDAEEAjBBBgkrBgEEAaAyAR4wNDAy
# BggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9y
# eS8wDAYDVR0TAQH/BAIwADCBkAYIKwYBBQUHAQEEgYMwgYAwOQYIKwYBBQUHMAGG
# LWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL2NhL2dzdHNhY2FzaGEzODRnNDBD
# BggrBgEFBQcwAoY3aHR0cDovL3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQv
# Z3N0c2FjYXNoYTM4NGc0LmNydDAfBgNVHSMEGDAWgBTqFsZp5+PLV0U5M6TwQL7Q
# w71lljBBBgNVHR8EOjA4MDagNKAyhjBodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29t
# L2NhL2dzdHNhY2FzaGEzODRnNC5jcmwwDQYJKoZIhvcNAQEMBQADggIBAGYfzwRh
# xCcMMGOdFylYezH0PcaS6ABq/E3xefhnLFLxh09UMeb2gE/XPDuBDaOR1ArLelps
# wVILQvkpBswzfheaZ0j/w+cjq/E03In7HD88F9WRn72NxokSBVMOdpEGqyWdZyeI
# cv1Db2Eprmb2vIwiuMNes5/frxqDRf2w724UX07LumLYVRNDtH4dIl7qlqyfd+cn
# 3e6s/uWNJGOyF0Yk9U3w6ibkAVmo9W2JqSMRycQ8cC7svE/kuq3GgzscSOZoqzn3
# MKakNLDjVpu9z7Gh36RrulCrqVFdvZDAghLPFiXGxVc+7JyslVqFybbCOkzUvME0
# 8bvdxwRjIMDBgPSSQGrhGsKRGdzn9MP3VJ9QpHCuAr29v3n4tGSdo7N53HM+0WBY
# gmesiKzGajy79/4pROfkamQQzM+iergtga0cNaq9hK8npbrChB0NSA+qBpTxggf0
# mczlUveZF+IF6IW4+NJxBb2/pUFfyfSqg3PR+G3D+gTSkAg/dcS0Dk5f0Jjq0uqk
# TjA4w0L3qd4FjZNd0sNtATCIIWT7FN6nsMSNBtWSPXXmR3U98AfG0/517/SBxiCg
# AvOWx0hmDTCdpUJfR3vak2OxBlZRQxfudAg80Gy8XJ2x5XlbTcBayAHhD2jtm91F
# dEglFFxSM05mS/AJeDEw29LVZTlRsGBMYx6QMIIGWTCCBEGgAwIBAgINAewckkDe
# /S5AXXxHdDANBgkqhkiG9w0BAQwFADBMMSAwHgYDVQQLExdHbG9iYWxTaWduIFJv
# b3QgQ0EgLSBSNjETMBEGA1UEChMKR2xvYmFsU2lnbjETMBEGA1UEAxMKR2xvYmFs
# U2lnbjAeFw0xODA2MjAwMDAwMDBaFw0zNDEyMTAwMDAwMDBaMFsxCzAJBgNVBAYT
# AkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMTEwLwYDVQQDEyhHbG9iYWxT
# aWduIFRpbWVzdGFtcGluZyBDQSAtIFNIQTM4NCAtIEc0MIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA8ALiMCP64BvhmnSzr3WDX6lHUsdhOmN8OSN5bXT8
# MeR0EhmW+s4nYluuB4on7lejxDXtszTHrMMM64BmbdEoSsEsu7lw8nKujPeZWl12
# rr9EqHxBJI6PusVP/zZBq6ct/XhOQ4j+kxkX2e4xz7yKO25qxIjw7pf23PMYoEuZ
# HA6HpybhiMmg5ZninvScTD9dW+y279Jlz0ULVD2xVFMHi5luuFSZiqgxkjvyen38
# DljfgWrhsGweZYIq1CHHlP5CljvxC7F/f0aYDoc9emXr0VapLr37WD21hfpTmU1b
# dO1yS6INgjcZDNCr6lrB7w/Vmbk/9E818ZwP0zcTUtklNO2W7/hn6gi+j0l6/5Cx
# 1PcpFdf5DV3Wh0MedMRwKLSAe70qm7uE4Q6sbw25tfZtVv6KHQk+JA5nJsf8sg2g
# lLCylMx75mf+pliy1NhBEsFV/W6RxbuxTAhLntRCBm8bGNU26mSuzv31BebiZtAO
# BSGssREGIxnk+wU0ROoIrp1JZxGLguWtWoanZv0zAwHemSX5cW7pnF0CTGA8zwKP
# Af1y7pLxpxLeQhJN7Kkm5XcCrA5XDAnRYZ4miPzIsk3bZPBFn7rBP1Sj2HYClWxq
# jcoiXPYMBOMp+kuwHNM3dITZHWarNHOPHn18XpbWPRmwl+qMUJFtr1eGfhA3HWsa
# FN8CAwEAAaOCASkwggElMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAGAQH/
# AgEAMB0GA1UdDgQWBBTqFsZp5+PLV0U5M6TwQL7Qw71lljAfBgNVHSMEGDAWgBSu
# bAWjkxPioufi1xzWx/B/yGdToDA+BggrBgEFBQcBAQQyMDAwLgYIKwYBBQUHMAGG
# Imh0dHA6Ly9vY3NwMi5nbG9iYWxzaWduLmNvbS9yb290cjYwNgYDVR0fBC8wLTAr
# oCmgJ4YlaHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9yb290LXI2LmNybDBHBgNV
# HSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFs
# c2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZIhvcNAQEMBQADggIBAH/iiNlXZytC
# X4GnCQu6xLsoGFbWTL/bGwdwxvsLCa0AOmAzHznGFmsZQEklCB7km/fWpA2PHpby
# hqIX3kG/T+G8q83uwCOMxoX+SxUk+RhE7B/CpKzQss/swlZlHb1/9t6CyLefYdO1
# RkiYlwJnehaVSttixtCzAsw0SEVV3ezpSp9eFO1yEHF2cNIPlvPqN1eUkRiv3I2Z
# OBlYwqmhfqJuFSbqtPl/KufnSGRpL9KaoXL29yRLdFp9coY1swJXH4uc/LusTN76
# 3lNMg/0SsbZJVU91naxvSsguarnKiMMSME6yCHOfXqHWmc7pfUuWLMwWaxjN5Fk3
# hgks4kXWss1ugnWl2o0et1sviC49ffHykTAFnM57fKDFrK9RBvARxx0wxVFWYOh8
# lT0i49UKJFMnl4D6SIknLHniPOWbHuOqhIKJPsBK9SH+YhDtHTD89szqSCd8i3VC
# f2vL86VrlR8EWDQKie2CUOTRe6jJ5r5IqitV2Y23JSAOG1Gg1GOqg+pscmFKyfpD
# xMZXxZ22PLCLsLkcMe+97xTYFEBsIB3CLegLxo1tjLZx7VIh/j72n585Gq6s0i96
# ILH0rKod4i0UnfqWah3GPMrz2Ry/U02kR1l8lcRDQfkl4iwQfoH5DZSnffK1CfXY
# YHJAUJUg1ENEvvqglecgWbZ4xqRqqiKbMIIFgzCCA2ugAwIBAgIORea7A4Mzw4Vl
# SOb/RVEwDQYJKoZIhvcNAQEMBQAwTDEgMB4GA1UECxMXR2xvYmFsU2lnbiBSb290
# IENBIC0gUjYxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzARBgNVBAMTCkdsb2JhbFNp
# Z24wHhcNMTQxMjEwMDAwMDAwWhcNMzQxMjEwMDAwMDAwWjBMMSAwHgYDVQQLExdH
# bG9iYWxTaWduIFJvb3QgQ0EgLSBSNjETMBEGA1UEChMKR2xvYmFsU2lnbjETMBEG
# A1UEAxMKR2xvYmFsU2lnbjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AJUH6HPKZvnsFMp7PPcNCPG0RQssgrRIxutbPK6DuEGSMxSkb3/pKszGsIhrxbaJ
# 0cay/xTOURQh7ErdG1rG1ofuTToVBu1kZguSgMpE3nOUTvOniX9PeGMIyBJQbUJm
# L025eShNUhqKGoC3GYEOfsSKvGRMIRxDaNc9PIrFsmbVkJq3MQbFvuJtMgamHvm5
# 66qjuL++gmNQ0PAYid/kD3n16qIfKtJwLnvnvJO7bVPiSHyMEAc4/2ayd2F+4OqM
# PKq0pPbzlUoSB239jLKJz9CgYXfIWHSw1CM69106yqLbnQneXUQtkPGBzVeS+n68
# UARjNN9rkxi+azayOeSsJDa38O+2HBNXk7besvjihbdzorg1qkXy4J02oW9UivFy
# Vm4uiMVRQkQVlO6jxTiWm05OWgtH8wY2SXcwvHE35absIQh1/OZhFj931dmRl4QK
# bNQCTXTAFO39OfuD8l4UoQSwC+n+7o/hbguyCLNhZglqsQY6ZZZZwPA1/cnaKI0a
# EYdwgQqomnUdnjqGBQCe24DWJfncBZ4nWUx2OVvq+aWh2IMP0f/fMBH5hc8zSPXK
# bWQULHpYT9NLCEnFlWQaYw55PfWzjMpYrZxCRXluDocZXFSxZba/jJvcE+kNb7gu
# 3GduyYsRtYQUigAZcIN5kZeR1BonvzceMgfYFGM8KEyvAgMBAAGjYzBhMA4GA1Ud
# DwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBSubAWjkxPioufi
# 1xzWx/B/yGdToDAfBgNVHSMEGDAWgBSubAWjkxPioufi1xzWx/B/yGdToDANBgkq
# hkiG9w0BAQwFAAOCAgEAgyXt6NH9lVLNnsAEoJFp5lzQhN7craJP6Ed41mWYqVuo
# PId8AorRbrcWc+ZfwFSY1XS+wc3iEZGtIxg93eFyRJa0lV7Ae46ZeBZDE1ZXs6Kz
# O7V33EByrKPrmzU+sQghoefEQzd5Mr6155wsTLxDKZmOMNOsIeDjHfrYBzN2VAAi
# KrlNIC5waNrlU/yDXNOd8v9EDERm8tLjvUYAGm0CuiVdjaExUd1URhxN25mW7xoc
# BFymFe944Hn+Xds+qkxV/ZoVqW/hpvvfcDDpw+5CRu3CkwWJ+n1jez/QcYF8AOiY
# rg54NMMl+68KnyBr3TsTjxKM4kEaSHpzoHdpx7Zcf4LIHv5YGygrqGytXm3ABdJ7
# t+uA/iU3/gKbaKxCXcPu9czc8FB10jZpnOZ7BN9uBmm23goJSFmH63sUYHpkqmlD
# 75HHTOwY3WzvUy2MmeFe8nI+z1TIvWfspA9MRf/TuTAjB0yPEL+GltmZWrSZVxyk
# zLsViVO6LAUP5MSeGbEYNNVMnbrt9x+vJJUEeKgDu+6B5dpffItKoZB0JaezPkvI
# LFa9x8jvOOJckvB595yEunQtYQEgfn7R8k8HWV+LLUNS60YMlOH1Zkd5d9VUWx+t
# JDfLRVpOoERIyNiwmcUVhAn21klJwGW45hpxbqCo8YLoRT5s1gLXCmeDBVrJpBAx
# ggNJMIIDRQIBATBvMFsxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWdu
# IG52LXNhMTEwLwYDVQQDEyhHbG9iYWxTaWduIFRpbWVzdGFtcGluZyBDQSAtIFNI
# QTM4NCAtIEc0AhABAzLhZb+beEPgmXWUY3cLMAsGCWCGSAFlAwQCAaCCAS0wGgYJ
# KoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMCsGCSqGSIb3DQEJNDEeMBwwCwYJYIZI
# AWUDBAIBoQ0GCSqGSIb3DQEBCwUAMC8GCSqGSIb3DQEJBDEiBCAeXn3dQLmcD874
# s90U2IA/oZBIy3cQPoo3KZ4k8vSn2TCBsAYLKoZIhvcNAQkQAi8xgaAwgZ0wgZow
# gZcEIJGSR5tiNbl2Jr+2AW14CJGDcgPYc5HAbBuOPXf/4sc3MHMwX6RdMFsxCzAJ
# BgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMTEwLwYDVQQDEyhH
# bG9iYWxTaWduIFRpbWVzdGFtcGluZyBDQSAtIFNIQTM4NCAtIEc0AhABAzLhZb+b
# eEPgmXWUY3cLMA0GCSqGSIb3DQEBCwUABIIBgEdNcSy3v2uz3Waozk0HSbDDRmGw
# A1Q6OQ7U95eyuAkBN1iPNnScaUJ9LLFtyzcnIAbi+TJZxDfKiicIAJ8r2F0U0w9C
# Vx2JM2m61XiYrr/SUF+86IvOTq19hBmLIE+y3t/RW0qvGcWqhbo/8OAKtc2Mb9OB
# ZnLc0CHDB7d2GH/ijxVLka5uWsc/jooQ7fCOlht5vQGS9DWkQwU+LFgViafm0sEb
# 8Gyc8KCGzrAHhC7tRsVMlzPthUB3T91nb2g67whzeZZ26qaKgGkOAndGatokgSM/
# KJezeeP7GQk7xtwQajuJIpe8L/7i8AP3EVy3bEIqhHaPzCOLtC8D3Re5ZsT9aaVV
# 9bMMa4863qSUkraUP7hv0IOrpjtpaSosbhheMhr/kkXB8qLVqcN0gq8hCwwSQrc/
# H4mdPCruFNRZDkVecuEVv8I1D5AJMMHFOxP+srokXMWtGdGs4xihHPwz7Y8X/yRS
# ukDaoGf5Ky3rqSghOUztFiYhSf3X4P9a27MX+g==
# SIG # End signature block
