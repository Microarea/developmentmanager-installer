$apps = @(
		[pscustomobject]@{AppName='nvm';Version='1.1.11'}
		[pscustomobject]@{AppName='zstd';Version='1.5.5'}
		[pscustomobject]@{AppName='winget';Version='1.8.1911'}
		[pscustomobject]@{AppName='git';Version='2.51.0'}
   )

#-------------------------------------------------------------------------------------------------
function InstallScoopIfNeeded()
{
	$scoopMainFile = Get-Command -ErrorAction SilentlyContinue scoop
	
	# $scoopMainFile is null or empty if previuos command produce error
	If (![string]::IsNullOrWhitespace($scoopMainFile)) {		
		Write-Host scoop already installed -ForegroundColor Green
		scoop update
		return 
		
	}
	Write-Host installing scoop
	iex "& {$(irm get.scoop.sh)} -RunAsAdmin"
}

#-------------------------------------------------------------------------------------------------
function ExecuteScoopInstall([string] $package)
{
	$job = Start-Job -ScriptBlock {
		param($processName)
		CheckAndInstallWithScoop -processName $processName
	} -ArgumentList  $package -InitializationScript $scriptBlock
	return $job
}

#-------------------------------------------------------------------------------------------------
function ExecuteNpmInstall([string] $package, [string] $version)
{
	$job = Start-Job -ScriptBlock {
		param($package, $version)
		CheckAndInstallWithNpm -package $package -version $version
	} -ArgumentList $package,  $version  -InitializationScript $scriptBlock
	return $job
}

$scriptBlock = 
{
	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopVersionNumber([string] $scoopAppName)
	{
		ForEach ($app In $apps)
		{
			if ($app.AppName -eq $scoopAppName)
			{
				return $app.Version
			}
		}
	
		return ""
	}

	#-------------------------------------------------------------------------------------------------
	function ExistFile([string] $fileFullPath)
	{
		If ($fileFullPath -eq '') {	
			write-host non esiste
			return $false;
		}
	
		return Test-Path -Path $fileFullPath -PathType Leaf -ErrorAction SilentlyContinue
	}


	#-------------------------------------------------------------------------------------------------
	function InstallWithScoop([string] $processName, [string] $version)
	{
		Write-Host installing $processName ...
	
		$proc  = $processName
		If (![string]::IsNullOrWhitespace($version)) {		
		
			$proc += "@" + $version
			write-host $proc
		}
		$processingInstall = scoop install -g $proc	
	}

	#-------------------------------------------------------------------------------------------------
	function RetrieveScoopPath([string] $processName) 
	{
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
		If ($alreadyExistFile -eq $true) {	
			return $processFile
		}
		return $null
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithScoop([string] $processName)
	{
		Write-Host checking $processName installation...
	
		$processFile = scoop which $processName
		$alreadyExistFile = ExistFile $processFile 
	
		If ($alreadyExistFile -eq $true) 
		{	
			Write-Host $processName already installed -ForegroundColor Green
			return $processFile
		}
	
		Write-Host  $processName not found, installing...
	
		$version = RetrieveScoopVersionNumber $processName
	
		InstallWithScoop $processName $version
	
		$path = RetrieveScoopPath $processName

		return $path 
	}

	#-------------------------------------------------------------------------------------------------
	function CheckAndInstallWithNpm([string] $package, [string] $version)
	{
		$string = npm list --depth 0 --global $package | findstr $package
		if (![string]::IsNullOrEmpty($string)) 
		{
			Write-host "$package found"
			return
		}
	
		$packageWithVersion = $package
		if (![string]::IsNullOrEmpty($version))
		{
			$packageWithVersion = "$packageWithVersion@$version"
		}
		write-host "npm i -g $packageWithVersion"
		$res = npm i -g $packageWithVersion
	}
}

Write-host Checking prerequisites, please wait...

InstallScoopIfNeeded

$jobArray = New-Object -TypeName System.Collections.ArrayList

 [void]$jobArray.Add((ExecuteScoopInstall "git" )) 
 [void]$jobArray.Add((ExecuteScoopInstall "zstd"))
 [void]$jobArray.Add((ExecuteScoopInstall "winget"))
 [void]$jobArray.Add((ExecuteScoopInstall "nvm"))

Receive-Job -Job $jobArray  -Wait 

$nodeVersion="22.13.0" 
nvm install $nodeVersion 
nvm use $nodeVersion 

$jobArray.Clear()

 [void]$jobArray.Add((ExecuteNpmInstall "rimraf" "6.0.1" ))
 [void]$jobArray.Add((ExecuteNpmInstall "@angular/cli" "18.2.5"))

Receive-Job -Job $jobArray  -Wait 

Write-Host prerequisites successfully installed
# SIG # Begin signature block
# MII1bgYJKoZIhvcNAQcCoII1XzCCNVsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBmWX5CyuGyNnHg
# vjf+OjRQzxHxVDtFuCu+var5W2dvFKCCE6QwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdYMIIFQKADAgECAhALY7FEOp3D0E4VNYGo0wZaMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjUwMTA3MDAwMDAwWhcNMjgwMTA2MjM1OTU5WjBgMQsw
# CQYDVQQGEwJJVDESMBAGA1UECBMJTG9tYmFyZGlhMQ0wCwYDVQQHEwRMb2RpMRYw
# FAYDVQQKEw1adWNjaGV0dGkgU3BBMRYwFAYDVQQDEw1adWNjaGV0dGkgU3BBMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3TaQlQcBgxfabFLVq5czkhW1
# gTdCfXaoUnx2VRkKnlDbeA/mktrWbKwKBQCGLboy734CoJz/7aQys0sQJ25CLh7B
# tcu8OKpTgyV1oO4sIg8z2XYOA258LFYW0dlDdkBpU6nOsaSIUbefsa+2WLOA9V1B
# I7P54GbSVPbcam9AsM4bI6pH+PxxPHIR24LLXOxmLx6UMiP3QILtPlasERpDL/l1
# 9mnpAr8EaHavGBHLYgZRtqxS5fG6o4fG+Dkd9l2Mxveb3OGXLesJquS3h9NRfVwE
# EImjTUMRcHIJwNxz1hm9d8yxWUc5M2jhiN3FMsvHRgi6/skIEAvZuNX6obNG3Sm/
# PR3+M+KNVEa0BS0zHUGzEjbw6KzS4fKLFWtnkdYwE5g3A0nrkX8YURP5YoySbkV0
# 7qJ/cu+pgcfmU5oCk8bIUYFK3cVCuRGsqbCj1h8jjriXSXeifgx47CvTHA2XozCu
# YnUeoZQkmc+nhF7LqrbRdRtJVXdQpucb5N/QoDW0z9XmIY33fLWnPH86yK9MP3QP
# 95B03VR4vgW0zzHzeYOC8pU/eKLdMjlgE4NXmI7p1a+cwjQXA6H9yJ6N0v4g/c1f
# I1sjHCrihZ7V9+JgojZSbBCST/PsWp+IrZSK5xvNZNfT1NgV+u5l3SKaLcxY+lzz
# ypd/3YTHoGdI3I74JakCAwEAAaOCAgMwggH/MB8GA1UdIwQYMBaAFGg34Ou2O/hf
# EYb7/mF7CIhl9E5CMB0GA1UdDgQWBBQEQbu7d7WI8BgYORO6AXiqJbpJuTA+BgNV
# HSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIBFhtodHRwOi8vd3d3LmRpZ2lj
# ZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMD
# MIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEu
# Y3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDCBlAYIKwYB
# BQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcnQw
# CQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEAP790s7hk/lROJkN/2hncbK45
# xQUhaE7snFu5NPI76RP2moIW7v6xEtc2cTHOAU/Bh5NqWtOWv1hKVNX2AbTPiMKq
# 0ghVA3gE8LC6mePQgCDNNWM0VFWlAwFFr+mXXWJeWEQIdKYDAHWwR0KyvseKy5FQ
# WQXo46RHClsLhWn3VTkZOkz9ErEj5akP7jLfDBjizVx/6B5/Nf8FJZwpy+EsJY4h
# CgsLtcgWrESKPRZnhccDlmG9IFPm7DUktf7By4U+IZJDQVFhrP0AwB7HxiP/JCds
# 1IkFBUA05hC2iD0Ybg11UVSGwI8w+RfRMPCCX6WPUMOiT8Vqq4+JGM7grPv9rTxh
# ilH14WxF4UJB4osO1ySVuPl9IXp/QJjbs81TiQKMaxYnCNC2wOcqibyzqNUkGWhp
# X6edZ18fRAXU6AxRu7GAQ4dDYP6sNqa2u606yTFMG8IEg6Fw5X7bot90i/uez57m
# Zfo52VQF1dmojsAgvwuGczgHfiHr5BWTDo+QijfNbE9vEOTCYVWTco7R5Hoxkg6O
# 4b8lhs5xMfZA0MRXImHxQ+rwMduiJbBN/abvVxUy0jXhwpk05OyRm1OwoFnHX4at
# Fv4iJcBm3IhkqFymhS6pJA4gVv6PnhPT0AqcDisGXLnYbvTaVWWP9NlY/Mm6qNlF
# K7vczdsxO3tftKXFfAwxgiEgMIIhHAIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYD
# VQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBH
# NCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQgMjAyMSBDQTECEAtjsUQ6ncPQ
# ThU1gajTBlowDQYJYIZIAWUDBAIBBQCggYQwGAYKKwYBBAGCNwIBDDEKMAigAoAA
# oQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4w
# DAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgXmkFv+EzAZIqZRLVdoanEa5H
# vgnTLBPBn0SN+yBNFSkwDQYJKoZIhvcNAQEBBQAEggIAObGIw3Yi7OTuS7WsARNz
# 0PjRlYgxPrNf9xS9O+w3vE2R6OT9O3V5rPweYVJ9YwCPTENn2EnwLF8Sa6LbTTTy
# 0vJFC++PbAn4Qznms+iOSSXeqOCsfgzCZelsWE1k6ELhOt6SAG8ZiJG6xQm0qGX3
# kw1jE2ePntijt7Ofmv/CoNi+JndhCiteC3/FFaH+YpQ/GP4tBU5FZwKwW3ERkR/G
# tGNaXu71VoSkvklA3JSVx6u1UvaVf5mzTMC+SQm/HU1815urEBJDwMDwtx2ihcI+
# +FOjdZwoWwh13CeOByGXGBjZKVlyQhNaIE475/lGGVGqeY0sXQRymxiV0YAFy3Ki
# D3EXPPia/+39Gtk8f+zY0XsTqBnO9uUMq64q/3LHaui94vEMZl/aCJ2dmoY2jfKG
# 2LaCA41uVHeQ2Q0OkJkZJeabXSVcvd1/c4GY+wMAnM1ZL9S+CeUlpxFg2CCZAty9
# +wZm8dumFGVWmyRYSurIEE7X8GrJ93jKNBixmIXkAPqY/s6Ib4EXqnQq1b2bMAYB
# RL8t5tgWjzmmAcW+hylzLE93lOwPNzLCetu9CEutvjU/XTyAjJ6F6G6uNASDIGfx
# Dw7kcblKUscOpHd9AI6QnLmirBflUph8BDBUEewgrNQUoY48VZOgzDkDhFcDXx34
# 1Pef9yjqEB3rME5oWWATeOChgh3tMIId6QYKKwYBBAGCNwMDATGCHdkwgh3VBgkq
# hkiG9w0BBwKggh3GMIIdwgIBAzENMAsGCWCGSAFlAwQCAjCB5AYLKoZIhvcNAQkQ
# AQSggdQEgdEwgc4CAQEGCysGAQQBoDICAwICMDEwDQYJYIZIAWUDBAIBBQAEIIpJ
# JrrzdsMeE6VnWVpDtzcoHffWNOTxBLW5dBFKmjRmAhRvXkJvCeNsKbNvThJtPz7u
# 7/DEvxgPMjAyNjA1MDcwODU0MTJaMAMCAQGgXaRbMFkxCzAJBgNVBAYTAkJFMRkw
# FwYDVQQKExBHbG9iYWxTaWduIG52LXNhMS8wLQYDVQQDEyZHbG9iYWxzaWduIFI0
# NSBUU0EgZm9yIENvZGVTaWduIDIwMjUxMKCCGWAwggaKMIIEcqADAgECAhEAhHI/
# wZXMFvHbK6L2YN8r5DANBgkqhkiG9w0BAQwFADBeMQswCQYDVQQGEwJCRTEZMBcG
# A1UEChMQR2xvYmFsU2lnbiBudi1zYTE0MDIGA1UEAxMrR2xvYmFsU2lnbiBPZmZs
# aW5lIFI0NSBUaW1lc3RhbXBpbmcgQ0EgMjAyNTAeFw0yNTEwMTUwNzI1MDRaFw0z
# NzAxMTAwMDAwMDBaMFkxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWdu
# IG52LXNhMS8wLQYDVQQDEyZHbG9iYWxzaWduIFI0NSBUU0EgZm9yIENvZGVTaWdu
# IDIwMjUxMDCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBANFKjaGNhkBI
# KKMJBJzZExA88qiMT/F/hSKNrYmewntKeXaAOjEqND0dxTqtUPymDLWwEp1XG0ss
# WFjeDNj88DaLAizpnMKfGyG2NKGw3VHLNGvNzgWr7TFDHqoANQyf3qaocT/SiTnc
# M9uakGSRQPK0Yzv2dB/D1ZXKZiAD5ORsDT9A6Y800khnoKNfS3fAl+EvRxqJe2EE
# EwRYrFPm/ZTtlFsKr8NUNcD2hfWIVUFVoGnHnswsvTSfIe7HQidhLtGvngze02Gb
# v7SZrGnJMVrnW5jU8e1Mky6n+XdEaihDljB4IfaEOhQ3Ao4LtCQVuSWE92rbsReS
# 56Dyos6dEOZU7Wv4HXIwBuXpC5XQv448HVIoEA+mYgWSWYnRKiJttSrGxPN6ON0j
# 7LBAtRxeKWiDApawnjqHrCOVTkBWpPsUQFjNYJO3qF/tItBs8azTYFryhpo1+jRI
# v5oCk33iW4QH/C4TWWCm2tyQvNtCUKnno6CQAlimpi66L5N+54IhTQIDAQABo4IB
# xjCCAcIwDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMAwG
# A1UdEwEB/wQCMAAwHQYDVR0OBBYEFDL60+EHaCeQawjSPx08jGU2KAYZMB8GA1Ud
# IwQYMBaAFHcCOwExDx50d8NIyMMHY1WIpTuiMIGlBggrBgEFBQcBAQSBmDCBlTBC
# BggrBgEFBQcwAYY2aHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vZ3NvZmZsaW5l
# cjQ1dGltZXN0YW1wY2EyMDI1ME8GCCsGAQUFBzAChkNodHRwOi8vc2VjdXJlLmds
# b2JhbHNpZ24uY29tL2NhY2VydC9nc29mZmxpbmVyNDV0aW1lc3RhbXBjYTIwMjUu
# Y3J0MEoGA1UdHwRDMEEwP6A9oDuGOWh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20v
# Z3NvZmZsaW5lcjQ1dGltZXN0YW1wY2EyMDI1LmNybDBWBgNVHSAETzBNMAgGBmeB
# DAEEAjBBBgkrBgEEAaAyAR4wNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xv
# YmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZIhvcNAQEMBQADggIBAI6ucKaP
# R4aRim6eLPr9YWb3WzoqOeGQwpiVtx+2CkwG2WHKxWeIQ58G+Fy+gVDDgA4cb01F
# W9mmQGdqDkO3UczcmDbWBFUIHAXI/URPwgPGh+VjHk4PhII0sezq8KDqsWQ1PzW/
# 1nLy7TFfLdZug3mIr9JtOYsaoKsAYmKEsut8iG913BWt0HKIe14vGCO6BPolCiAJ
# KgEXYmqYfRkEKXnXlu1tO5ZkutBSzm++Xaj3wx2O73LIlFYvM9VxSRGT13zEEGLr
# fwUE4C6jd9zJOEZyd7vBQ5r5OCGHAgdtnenFNimCjlwLERmwfwRfCJNRPAd/Sp6y
# yyD/Zd1wYfuzQBHhPI4nZCcBrJg4Az9c4HE3NRFCDiaEx08v8XxUIwqPeSglpVzH
# ZqSHQHzaV79oFTyrY5r747A7CIcXl75/2b7KHJhvAZKiBYhXeGBGX5XIqtyHyC/f
# kUev9xXPyfT8I8ZFcaJglns/XA46Bh2QwPaIMpVhBvLkjH/EIHT+VIoueoSgV7N+
# acIlsaAAJWzAyzGEkRSO3ERxBz1p9qWd74g62zS//IJGKQmyeZVtLTHnQOTY4f5U
# KJT2z9fLOB8LtbOu1Dl2Ih1zYqyLckxMmbhrQuIQhlaK0Pn7o+iQ6RDz7flOwc7B
# SGzzsj/LImOUhmkBXg5/X8k3xtZUHcR2bhbOMIIGoDCCBIigAwIBAgIRAIPahje3
# nwyEDJR7hApSeB8wDQYJKoZIhvcNAQEMBQAwUzELMAkGA1UEBhMCQkUxGTAXBgNV
# BAoTEEdsb2JhbFNpZ24gbnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24gVGltZXN0
# YW1waW5nIFJvb3QgUjQ1MB4XDTI1MDcxNjAzMDUwNFoXDTQxMDcxNjAwMDAwMFow
# XjELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExNDAyBgNV
# BAMTK0dsb2JhbFNpZ24gT2ZmbGluZSBSNDUgVGltZXN0YW1waW5nIENBIDIwMjUw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCkdxb47X2L4t0ChkVjNL7l
# f5Zi+dagWpcB+KvWHKeFRN0fhFbUNv7I6atDbvmOWxDpvOhnec3QIydxlfgTRCGm
# npC/Hbv5+Wl/N4xBpwPtVyJZSIXdMuK7vBPZsEJIQ1SfeF8Ywbg8m9gW87mjgMDW
# I28eEbihLNy2h2gl9vhzwSNVqELD80uLMHetr41Z7aBkFJpkqtozEW3rvrKrHtFx
# CeNsXhHQ4sai+xm3be9Tr0DkF2g/F0D3O72sz6pMGw8NVQl7FjARVTQZjsEnmZRZ
# aeLIA8dbRa/gDOTm3sjRdQiMDf7Y4aSvR1UFdUEPIR4YFWthcR2F9UvC6HocEYkV
# 0isRjkqgaWmhP7gEFB7hcIfmy/XlSj4zvZUpaM8DkTHed8UkLg/kVbVJHqiUJJoi
# u2dnNz7OCalLKIP4ZwTa51BFAdsOLvh6deBrOTT6S2kdnVnyhO9JpIhESi9dItsf
# coLy4UiRe5yXtc8ftkYiuYX14XjO6ijkUhSey9XrSQuoUPM+T5RsuaBkNQI+UUUE
# F6Fpo2+LETKbH043Ypd6/4x8ro5kKGoZus4LbC+8AUfIqVNltUd2o2K7S7lrZPUL
# 11JNGfLX+HEvBzEv0FY/NAvCGyLJepTMzu4PSUP349gxrFRiChVLGpvjG88KJWos
# 1psj5a2MTNh9DQ/7q0FMWwIDAQABo4IBYjCCAV4wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMIMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYE
# FHcCOwExDx50d8NIyMMHY1WIpTuiMB8GA1UdIwQYMBaAFEayHHfhexXwpTmhcN7R
# xC7qbbLeMIGOBggrBgEFBQcBAQSBgTB/MDcGCCsGAQUFBzABhitodHRwOi8vb2Nz
# cC5nbG9iYWxzaWduLmNvbS90aW1lc3RhbXByb290cjQ1MEQGCCsGAQUFBzAChjho
# dHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2VydC90aW1lc3RhbXByb290
# cjQ1LmNydDA/BgNVHR8EODA2MDSgMqAwhi5odHRwOi8vY3JsLmdsb2JhbHNpZ24u
# Y29tL3RpbWVzdGFtcHJvb3RyNDUuY3JsMBEGA1UdIAQKMAgwBgYEVR0gADANBgkq
# hkiG9w0BAQwFAAOCAgEAMqPuftFu5GYxllheqUw9EmhHpfWf/+q5cYtV86kWhH1h
# rTkv3jDTLAGN6XIYZ/6cAH4JkVDuBQ53ZrZul+lbxfDkCsz5iM8R/wC0LgTpivXT
# lTVg2OVNIRGhYkpzWGRI3mbh2mxi14XKTMVBXBfnSFgoffJnpVy7odrQQDmh/Mum
# LaMraNtEMJdsU0uLmY7XEpF0HYDMAXR/kLTRvgfd3mwI4HyeNO8DBpMwYQx5OQtY
# zhn1j7dQ606mjVC7FdsOldWQtetobbmIvVW2+PEQDLjnfidQg0H3CE5GJwklJMtt
# rp84rZ//VAZYR17BYscDMT43mgfRCg1EAuknkmMh94ie876xB0GJ2c+4son3kdOP
# tfIy8mEVmO1sckaURbHhSApy40osMtdYAt/BAM3YN7LeRN93jLDidB2TU9y0ssrc
# Xgvaecu/3gEySlj5F+Xneg4Q3jJO+3AJg/5UO5muS1zs1pyhNXFmcoaS/xrVqRyR
# 07BBkL6LwDLVXLMwBf9Nvj6vdzrkHtykC2rc6hSKNdQmC9nFyLpNfvyyYvZNjLa1
# af7wbiSude/LYQtHZdicoQ5LgxWatIKyMzmfFKuCETXRUNdBsR9r3eWGKR8Wgi4g
# 0rNYMuq+7xm5ybES5/GkeM2edFVdf9m/kpCrym78xCg7PoMLvifn47ltLC9PmyAw
# ggajMIIEi6ADAgECAhB4SqqBc2ackAlU5CHJR+vAMA0GCSqGSIb3DQEBDAUAMEwx
# IDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9vdCBDQSAtIFI2MRMwEQYDVQQKEwpHbG9i
# YWxTaWduMRMwEQYDVQQDEwpHbG9iYWxTaWduMB4XDTIwMTIwOTAwMDAwMFoXDTM0
# MTIxMDAwMDAwMFowUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24g
# bnYtc2ExKTAnBgNVBAMTIEdsb2JhbFNpZ24gVGltZXN0YW1waW5nIFJvb3QgUjQ1
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAunQz7CfcEjghG8XTYSjW
# WrxP34vMkYRDJFe8ZCG8OxwfPU+MrQe388XXAukRFIKaqrSUcjtxDRrvaGuFeY6v
# ZupYmA26wXx50v/Ns28xRdAFdAQAcmonfrg3PzqI7ZeD9as1TQ+fWTv1L99ZxXyl
# MnZglsjt7vgEfhlRcqi/REF6vHseOwCbvLrglr+Q/o2bw3KLABL4IDpgOPfBzIWK
# +4d5LqErIObLoIWRI7bEKAdUKN7sEDFPivLNFB8e3VUc6igxTPkhaqjN85Zn+gFB
# m80PC2h/u97xQ+oX5bDccCKzaTZZdGvG5YkqfOULgV2rP4+40XZy83yiqeKXQb/M
# jEX+Ycn2bAcLAAToFSNPgiot9u/D+hE2SKHR/Xo5OjRdoywOm3dQIDRA3bEDMa1f
# 6WKHc5YDYfeUsNlcbE/nFMXh8XsNI5zNcIwdat5KLYsqu9tCFAUHqvsU3DHT9h9s
# y75oZkRwTW0X+XHrBXOOkZJ162hcHvZEYRgpYt0XZojsKLpJb9s+d/65MR91HBii
# pke92O5IhTv9s+IPPyqYxpr6gm+xpaWGHVo6+qRsdA93UmFqf4cp3jmbi+6zRWAw
# JJcVEiqFMJMmrJamLehwbQupMq0smygKdkLyVWFRmJTe7fbFF288FRCwDq2w3sUW
# 9GXRzC9aVgjPmcTwVZHCLHkCAwEAAaOCAXgwggF0MA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBRG
# shx34XsV8KU5oXDe0cQu6m2y3jAfBgNVHSMEGDAWgBSubAWjkxPioufi1xzWx/B/
# yGdToDB7BggrBgEFBQcBAQRvMG0wLgYIKwYBBQUHMAGGImh0dHA6Ly9vY3NwMi5n
# bG9iYWxzaWduLmNvbS9yb290cjYwOwYIKwYBBQUHMAKGL2h0dHA6Ly9zZWN1cmUu
# Z2xvYmFsc2lnbi5jb20vY2FjZXJ0L3Jvb3QtcjYuY3J0MDYGA1UdHwQvMC0wK6Ap
# oCeGJWh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20vcm9vdC1yNi5jcmwwRwYDVR0g
# BEAwPjA8BgRVHSAAMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNp
# Z24uY29tL3JlcG9zaXRvcnkvMA0GCSqGSIb3DQEBDAUAA4ICAQCLSLo2Vzxyxdp1
# +e8y9Ya93BIo44guTzZfJpnsDwEhEJaSOMZwa23zrtQOvSXvhn/iiY2VpX4pRANN
# qpio8bfc6iljIdztzYgKyxBpYXkpQgwjvOnF71IeLzM31U9memapR1Qzsd0W8thk
# caMxlOVv9k1L4oRs0MklZ0/IS9DOSwXWPft9QfqKscAh4H4IsNlkK/nq8scK9M8u
# DDRg7my7kvA/8XtSEmh3WYH1HC6kOow5Aw3t5cyvZkh5Y9VJuP9L0iVPSE6TO5N3
# sJpIbLagHbN0nl+9IgQ7fDcNhbXDmrvdnFoDjbQNn0x2NNWFrUV7tZ+7Lom7rMi/
# kmNIxj/KF6oNvAARX4vo40OEikM0zf07wKJ72x+4Z8iMFd4/pn/HKO+hb2+yQc8C
# IusB+EvI0nZvJd9e2mhoPXtEBMJBbkk7p5hWBO3RJisElNvk7WaOPYCdpKRVeVBe
# 4/gaH8AWb5AVPIqmSKEMe7oq4LGphwVGm+0lVT03aZjtRpmYhUcKHmLb/ZzlwUNC
# jr3Pb/aMkf2C5J/sreOVVQXzSS9tNPf/Z+6ZQLvTmoBCQNojiWAfg3GStenmygr5
# 3cdsslhBnGaNmypvH29XBENcg107aZzeOfqETTXzextti/FvA8EpUuKUv3tUi99A
# egtwAnc/L4gHAgB10q/G1iIyGaM76DCCBYMwggNroAMCAQICDkXmuwODM8OFZUjm
# /0VRMA0GCSqGSIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9vdCBD
# QSAtIFI2MRMwEQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpHbG9iYWxTaWdu
# MB4XDTE0MTIxMDAwMDAwMFoXDTM0MTIxMDAwMDAwMFowTDEgMB4GA1UECxMXR2xv
# YmFsU2lnbiBSb290IENBIC0gUjYxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzARBgNV
# BAMTCkdsb2JhbFNpZ24wggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCV
# B+hzymb57BTKezz3DQjxtEULLIK0SMbrWzyug7hBkjMUpG9/6SrMxrCIa8W2idHG
# sv8UzlEUIexK3RtaxtaH7k06FQbtZGYLkoDKRN5zlE7zp4l/T3hjCMgSUG1CZi9N
# uXkoTVIaihqAtxmBDn7EirxkTCEcQ2jXPTyKxbJm1ZCatzEGxb7ibTIGph75ueuq
# o7i/voJjUNDwGInf5A959eqiHyrScC5757yTu21T4kh8jBAHOP9msndhfuDqjDyq
# tKT285VKEgdt/Yyyic/QoGF3yFh0sNQjOvddOsqi250J3l1ELZDxgc1Xkvp+vFAE
# YzTfa5MYvms2sjnkrCQ2t/DvthwTV5O23rL44oW3c6K4NapF8uCdNqFvVIrxclZu
# LojFUUJEFZTuo8U4lptOTloLR/MGNkl3MLxxN+Wm7CEIdfzmYRY/d9XZkZeECmzU
# Ak10wBTt/Tn7g/JeFKEEsAvp/u6P4W4LsgizYWYJarEGOmWWWcDwNf3J2iiNGhGH
# cIEKqJp1HZ46hgUAntuA1iX53AWeJ1lMdjlb6vmlodiDD9H/3zAR+YXPM0j1ym1k
# FCx6WE/TSwhJxZVkGmMOeT31s4zKWK2cQkV5bg6HGVxUsWW2v4yb3BPpDW+4Ltxn
# bsmLEbWEFIoAGXCDeZGXkdQaJ783HjIH2BRjPChMrwIDAQABo2MwYTAOBgNVHQ8B
# Af8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUrmwFo5MT4qLn4tcc
# 1sfwf8hnU6AwHwYDVR0jBBgwFoAUrmwFo5MT4qLn4tcc1sfwf8hnU6AwDQYJKoZI
# hvcNAQEMBQADggIBAIMl7ejR/ZVSzZ7ABKCRaeZc0ITe3K2iT+hHeNZlmKlbqDyH
# fAKK0W63FnPmX8BUmNV0vsHN4hGRrSMYPd3hckSWtJVewHuOmXgWQxNWV7Oiszu1
# d9xAcqyj65s1PrEIIaHnxEM3eTK+teecLEy8QymZjjDTrCHg4x362AczdlQAIiq5
# TSAucGja5VP8g1zTnfL/RAxEZvLS471GABptArolXY2hMVHdVEYcTduZlu8aHARc
# phXveOB5/l3bPqpMVf2aFalv4ab733Aw6cPuQkbtwpMFifp9Y3s/0HGBfADomK4O
# eDTDJfuvCp8ga907E48SjOJBGkh6c6B3ace2XH+CyB7+WBsoK6hsrV5twAXSe7fr
# gP4lN/4Cm2isQl3D7vXM3PBQddI2aZzmewTfbgZptt4KCUhZh+t7FGB6ZKppQ++R
# x0zsGN1s71MtjJnhXvJyPs9UyL1n7KQPTEX/07kwIwdMjxC/hpbZmVq0mVccpMy7
# FYlTuiwFD+TEnhmxGDTVTJ267fcfrySVBHioA7vugeXaX3yLSqGQdCWnsz5LyCxW
# vcfI7zjiXJLwefechLp0LWEBIH5+0fJPB1lfiy1DUutGDJTh9WZHeXfVVFsfrSQ3
# y0VaTqBESMjYsJnFFYQJ9tZJScBluOYacW6gqPGC6EU+bNYC1wpngwVayaQQMYID
# YTCCA10CAQEwczBeMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBu
# di1zYTE0MDIGA1UEAxMrR2xvYmFsU2lnbiBPZmZsaW5lIFI0NSBUaW1lc3RhbXBp
# bmcgQ0EgMjAyNQIRAIRyP8GVzBbx2yui9mDfK+QwCwYJYIZIAWUDBAICoIIBQTAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwKwYJKoZIhvcNAQk0MR4wHDALBglg
# hkgBZQMEAgKhDQYJKoZIhvcNAQEMBQAwPwYJKoZIhvcNAQkEMTIEMHeeRnQbHHzl
# gKwM7yS0f6G5TdsuYNAxc4J70841MwvHgOBVxdEMZses/j544p+rsTCBtAYLKoZI
# hvcNAQkQAi8xgaQwgaEwgZ4wgZsEIIMq1y5SP96sg/pGlLznxswmF2SIKGZWZYjI
# rco6g4VRMHcwYqRgMF4xCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWdu
# IG52LXNhMTQwMgYDVQQDEytHbG9iYWxTaWduIE9mZmxpbmUgUjQ1IFRpbWVzdGFt
# cGluZyBDQSAyMDI1AhEAhHI/wZXMFvHbK6L2YN8r5DANBgkqhkiG9w0BAQwFAASC
# AYCBNpmUVb7G4n58N/ljc6kNxKylPxfGirCNACyu91qIErbQczXS0ImUL7gOLbUx
# d12Ek9tsOzybkyqbAtcThijMYWxcHbzJ/ACqGQelsZUwawiwM6qbgYd5vlYHM2Jr
# 1kRAaLM9yMdPMRArPjsTcbWyQBCGNoK2GzCBT77PRyX5xb8skZR5IlSyFN/v7Qo7
# Pkk3KN3NYvpb4nw5UJCucL38zUfQLk93zBjlUuIVTaKsLiPR6JJTJz5Thzg5EXWc
# qjXJnORCCEy9Oh9jc1smfQ7QrMEghFc240f74RgZ8odzhLEIrrdruqLOdbWBXoic
# cB6H68F8ooJ3NNLPiuiTpoMvywwufyb+LFMcLbmIkma9mvUGxqeDIkSNhMNRn7Nf
# hrHoFyQgHBxhejJGmPYH9Ui6x0s+KDQ+x3RemRGKGJ6BNTbuF3SR3I1mWWrNxwFl
# cglp6pnSR+IgP+0J7se9pEQ6/nZ30a6+qIOIxl0cwm/91uLjf2TOko2CgjmalKwT
# x00=
# SIG # End signature block
